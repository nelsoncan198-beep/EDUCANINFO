"use client";
import { useState } from "react";
import Link from "next/link";
import { CheckCircle2, Loader2, MessageCircle, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useCart } from "./CartProvider";
import { fmtCOP } from "@/lib/format";
import { WHATSAPP } from "@/lib/data";

const inputCls = "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold";

export default function CartCheckout({ userName = "", userPhone = "" }: { userName?: string; userPhone?: string }) {
  const { items, total, setQty, remove, clear } = useCart();
  const [form, setForm] = useState({ customerName: userName, phone: userPhone, address: "" });
  const [loading, setLoading] = useState(false); const [done, setDone] = useState<{ id: number; wa: string } | null>(null); const [error, setError] = useState("");
  const delivery = total >= 150000 || total === 0 ? 0 : 8000;

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const r = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, items: items.map((i) => ({ name: i.name, qty: i.qty, price: i.price })) }) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error); return; }
    setDone({ id: d.order.id, wa: d.whatsapp }); clear();
  }

  if (done) return (
    <div className="mx-auto max-w-xl rounded-[2rem] bg-emerald-50 p-8 text-center ring-1 ring-emerald-200">
      <CheckCircle2 className="mx-auto h-14 w-14 text-emerald-500" />
      <h2 className="font-display mt-4 text-3xl font-semibold text-emerald-900">¡Pedido #{done.id} recibido!</h2>
      <p className="mt-2 font-semibold text-emerald-800">Confirmemos tu entrega por WhatsApp para coordinar el pago y el envío.</p>
      <a target="_blank" href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(done.wa)}`} className="mt-5 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-7 py-4 font-extrabold text-white hover:bg-emerald-600"><MessageCircle className="h-5 w-5" /> Enviar pedido por WhatsApp</a>
      <Link href="/tienda" className="mt-4 block font-extrabold text-emerald-700">Seguir comprando</Link>
    </div>
  );

  if (items.length === 0) return (
    <div className="mx-auto max-w-xl rounded-[2rem] bg-white p-10 text-center ring-1 ring-brand-100">
      <ShoppingBag className="mx-auto h-14 w-14 text-brand-200" />
      <h2 className="font-display mt-4 text-2xl font-semibold text-brand-950">Tu carrito está vacío</h2>
      <p className="mt-2 text-slate-600">Encuentra concentrado, premios, arneses y todo lo que tu perro necesita en la tienda EDUCAN.</p>
      <Link href="/tienda" className="mt-5 inline-block rounded-full bg-brand-900 px-7 py-3.5 font-extrabold text-white">Ir a la tienda</Link>
    </div>
  );

  return (
    <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
      <div className="space-y-3">
        {items.map((i) => (
          <article key={i.id} className="flex gap-4 rounded-3xl bg-white p-4 ring-1 ring-brand-100">
            <img src={i.image} alt={i.name} className="h-24 w-24 shrink-0 rounded-2xl object-cover" />
            <div className="min-w-0 flex-1">
              <h3 className="font-display font-semibold leading-snug text-brand-950">{i.name}</h3>
              <p className="mt-1 font-black text-brand-800">{fmtCOP(i.price * i.qty)}</p>
              <div className="mt-2 flex items-center gap-3">
                <span className="inline-flex items-center gap-2 rounded-full bg-brand-50 px-2 py-1">
                  <button onClick={() => setQty(i.id, i.qty - 1)} className="grid h-7 w-7 place-items-center rounded-full bg-white shadow-sm"><Minus className="h-4 w-4" /></button>
                  <b className="min-w-5 text-center">{i.qty}</b>
                  <button onClick={() => setQty(i.id, i.qty + 1)} className="grid h-7 w-7 place-items-center rounded-full bg-white shadow-sm"><Plus className="h-4 w-4" /></button>
                </span>
                <button onClick={() => remove(i.id)} className="inline-flex items-center gap-1 text-sm font-extrabold text-rose-500"><Trash2 className="h-4 w-4" /> Quitar</button>
              </div>
            </div>
          </article>
        ))}
        <p className="rounded-2xl bg-brand-50 px-5 py-4 text-sm font-bold text-brand-800">Domicilio {delivery === 0 ? "GRATIS en pedidos desde $150.000" : `${fmtCOP(delivery)} · gratis desde $150.000`}. También puedes recoger en sede: Carrera 26 # 10-34, San Felipe.</p>
      </div>
      <form onSubmit={submit} className="h-fit rounded-3xl bg-white p-6 shadow-sm ring-1 ring-brand-100 lg:sticky lg:top-32">
        <h3 className="font-display text-2xl font-semibold text-brand-950">Finalizar pedido</h3>
        <div className="mt-4 space-y-3">
          <input required className={inputCls} placeholder="Tu nombre" value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} />
          <input required className={inputCls} placeholder="Tu WhatsApp" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <input className={inputCls} placeholder="Dirección de entrega (o 'Recoger en sede')" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </div>
        <dl className="mt-5 space-y-2 border-t border-dashed border-slate-200 pt-4 text-sm font-bold text-slate-600">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{fmtCOP(total)}</dd></div>
          <div className="flex justify-between"><dt>Domicilio</dt><dd>{delivery === 0 ? "GRATIS" : fmtCOP(delivery)}</dd></div>
          <div className="flex justify-between text-lg font-black text-brand-950"><dt>Total</dt><dd>{fmtCOP(total + delivery)}</dd></div>
        </dl>
        <p className="mt-2 text-xs font-semibold text-slate-500">El domicilio se coordina y puede pagarse contraentrega. Confirmas todo por WhatsApp.</p>
        {error && <p className="mt-3 rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600">{error}</p>}
        <button disabled={loading} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-accent-500 py-4 font-extrabold text-brand-950 hover:bg-accent-600 disabled:opacity-60">{loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <ShoppingBag className="h-5 w-5" />} Confirmar pedido</button>
      </form>
    </div>
  );
}

"use client";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Dog, Loader2, LogIn, UserPlus } from "lucide-react";

const inputCls = "w-full rounded-xl border border-slate-200 bg-white px-4 py-3.5 text-sm font-semibold";

export function LoginForm() {
  const router = useRouter(); const params = useSearchParams();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const r = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error); return; }
    router.push(params.get("next") || "/mi-cuenta"); router.refresh();
  }
  return (
    <form onSubmit={submit} className="rounded-[2rem] bg-white p-7 shadow-xl ring-1 ring-brand-100 sm:p-9">
      <h1 className="font-display text-3xl font-semibold text-brand-950">Hola de nuevo</h1>
      <p className="mt-2 text-sm text-slate-600">Ingresa para seguir entrenando con tu perro.</p>
      <div className="mt-6 space-y-3">
        <input required type="email" className={inputCls} placeholder="Correo electrónico" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <input required type="password" className={inputCls} placeholder="Contraseña" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
      </div>
      {error && <p className="mt-3 rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600">{error}</p>}
      <button disabled={loading} className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-brand-900 py-4 font-extrabold text-white hover:bg-brand-700 disabled:opacity-60">{loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <LogIn className="h-5 w-5" />} Ingresar a EducaInfo</button>
      <div className="mt-5 rounded-2xl bg-cream p-4 text-sm font-semibold text-slate-600">
        <p className="font-extrabold text-brand-900">Cuenta demo para explorar:</p>
        <p>Correo: <b>demo@educainfo.co</b> · Contraseña: <b>educan123</b></p>
      </div>
      <p className="mt-5 text-center text-sm font-semibold text-slate-600">¿Aún no tienes cuenta? <Link href="/registro" className="font-extrabold text-brand-700">Regístrate y prueba 7 días gratis</Link></p>
    </form>
  );
}

export function RegisterForm() {
  const router = useRouter(); const params = useSearchParams();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", dogName: "", dogBreed: "" });
  const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const r = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error); return; }
    router.push(params.get("next") || "/mi-cuenta?bienvenida=1"); router.refresh();
  }
  return (
    <form onSubmit={submit} className="rounded-[2rem] bg-white p-7 shadow-xl ring-1 ring-brand-100 sm:p-9">
      <span className="inline-flex items-center gap-2 rounded-full bg-emerald-100 px-3 py-1 text-xs font-extrabold text-emerald-700"><Dog className="h-4 w-4" /> 7 DÍAS GRATIS · SIN TARJETA</span>
      <h1 className="font-display mt-3 text-3xl font-semibold text-brand-950">Crea tu cuenta EducaInfo</h1>
      <p className="mt-2 text-sm text-slate-600">Acceso total a cursos de adiestramiento y guías de comportamiento desde hoy.</p>
      <div className="mt-6 space-y-3">
        <input required className={inputCls} placeholder="Tu nombre completo" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <div className="grid gap-3 sm:grid-cols-2">
          <input required type="email" className={inputCls} placeholder="Correo electrónico" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <input required className={inputCls} placeholder="WhatsApp" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </div>
        <input required type="password" minLength={6} className={inputCls} placeholder="Crea una contraseña (mín. 6 caracteres)" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <div className="rounded-2xl bg-brand-50 p-4">
          <p className="text-sm font-extrabold text-brand-900">Tu primer perro (puedes agregar más luego)</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <input className={inputCls} placeholder="Nombre de tu perro" value={form.dogName} onChange={(e) => setForm({ ...form, dogName: e.target.value })} />
            <input className={inputCls} placeholder="Raza (ej. Golden, Criollo...)" value={form.dogBreed} onChange={(e) => setForm({ ...form, dogBreed: e.target.value })} />
          </div>
        </div>
      </div>
      {error && <p className="mt-3 rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600">{error}</p>}
      <button disabled={loading} className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-accent-500 py-4 font-extrabold text-brand-950 hover:bg-accent-600 disabled:opacity-60">{loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <UserPlus className="h-5 w-5" />} Activar mis 7 días gratis</button>
      <p className="mt-4 text-center text-xs font-semibold text-slate-500">Al registrarte aceptas que te contactemos por WhatsApp para acompañar tu proceso. Sin spam.</p>
      <p className="mt-3 text-center text-sm font-semibold text-slate-600">¿Ya tienes cuenta? <Link href="/ingresar" className="font-extrabold text-brand-700">Ingresa aquí</Link></p>
    </form>
  );
}

"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { GraduationCap, HeartHandshake, Home, Menu, Phone, Scissors, ShoppingBag, Sparkles, User, X, Clock3, Crown } from "lucide-react";
import Logo from "./Logo";
import { useCart } from "./CartProvider";

const links = [
  { href: "/", label: "Inicio", icon: Home },
  { href: "/entrenamiento", label: "Adiestramiento", icon: GraduationCap },
  { href: "/comportamiento", label: "Comportamiento", icon: HeartHandshake },
  { href: "/spa", label: "Spa y Peluquería", icon: Scissors },
  { href: "/tienda", label: "Tienda", icon: ShoppingBag },
  { href: "/planes", label: "Planes", icon: Crown },
];

export default function Header({ userName, accessLabel, accessStatus }: { userName: string | null; accessLabel: string; accessStatus: string }) {
  const path = usePathname();
  const router = useRouter();
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); router.refresh(); router.push("/"); }
  return (
    <>
      <div className="bg-brand-950 text-white text-xs sm:text-[13px]">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-2">
          <p className="flex items-center gap-1.5 font-bold"><Sparkles className="h-3.5 w-3.5 text-accent-500" /> 7 días GRATIS en adiestramiento online · Sin tarjeta</p>
          <a href="tel:+573162826043" className="hidden sm:flex items-center gap-1.5 font-bold hover:text-accent-500"><Phone className="h-3.5 w-3.5" /> 316 282 6043</a>
        </div>
      </div>
      <header className="sticky top-0 z-50 border-b border-brand-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
          <Logo />
          <nav className="hidden lg:flex items-center gap-1">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className={`rounded-full px-3.5 py-2 text-sm font-extrabold transition ${path === l.href ? "bg-brand-900 text-white" : "text-slate-700 hover:bg-brand-50 hover:text-brand-800"}`}>{l.label}</Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            {userName ? (
              <>
                <span className={`hidden md:inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-extrabold ${accessStatus === "premium" ? "bg-accent-100 text-accent-600" : accessStatus === "trial" ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`}><Clock3 className="h-3.5 w-3.5" />{accessLabel}</span>
                <Link href="/mi-cuenta" className="hidden sm:inline-flex items-center gap-2 rounded-full bg-brand-900 px-4 py-2.5 text-sm font-extrabold text-white hover:bg-brand-700"><User className="h-4 w-4" />{userName.split(" ")[0]}</Link>
              </>
            ) : (
              <>
                <Link href="/ingresar" className="hidden sm:block rounded-full px-4 py-2.5 text-sm font-extrabold text-brand-800 hover:bg-brand-50">Ingresar</Link>
                <Link href="/registro" className="hidden sm:block rounded-full bg-accent-500 px-4 py-2.5 text-sm font-extrabold text-brand-950 hover:bg-accent-600">Prueba gratis</Link>
              </>
            )}
            <Link href="/carrito" className="relative grid h-11 w-11 place-items-center rounded-full bg-brand-50 text-brand-800 hover:bg-brand-100" aria-label="Carrito">
              <ShoppingBag className="h-5 w-5" />
              {count > 0 && <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-accent-500 px-1 text-[11px] font-black text-brand-950">{count}</span>}
            </Link>
            <button onClick={() => setOpen(!open)} className="grid h-11 w-11 place-items-center rounded-full bg-brand-50 text-brand-800 lg:hidden" aria-label="Menú">{open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}</button>
          </div>
        </div>
        {open && (
          <nav className="border-t border-brand-100 bg-white px-4 py-3 lg:hidden">
            <div className="grid gap-1">
              {links.map((l) => (<Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-3 font-extrabold text-slate-700 hover:bg-brand-50"><l.icon className="h-5 w-5 text-brand-600" />{l.label}</Link>))}
              {userName ? (
                <><Link href="/mi-cuenta" onClick={() => setOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-3 font-extrabold text-slate-700 hover:bg-brand-50"><User className="h-5 w-5 text-brand-600" />Mi cuenta ({accessLabel})</Link>
                <button onClick={logout} className="rounded-xl bg-rose-50 px-3 py-3 text-left font-extrabold text-rose-600">Cerrar sesión</button></>
              ) : (
                <div className="flex gap-2 pt-2"><Link href="/ingresar" className="flex-1 rounded-full border-2 border-brand-900 py-3 text-center font-extrabold text-brand-900">Ingresar</Link><Link href="/registro" className="flex-1 rounded-full bg-accent-500 py-3 text-center font-extrabold text-brand-950">7 días gratis</Link></div>
              )}
            </div>
          </nav>
        )}
      </header>
      {/* Barra inferior tipo APK en móvil */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 grid grid-cols-5 border-t border-brand-100 bg-white pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_24px_rgba(7,31,61,.08)] lg:hidden">
        {[{ href: "/", label: "Inicio", icon: Home }, { href: "/entrenamiento", label: "Cursos", icon: GraduationCap }, { href: "/spa", label: "Spa", icon: Scissors }, { href: "/tienda", label: "Tienda", icon: ShoppingBag }, { href: "/mi-cuenta", label: "Cuenta", icon: User }].map((l) => {
          const active = path === l.href;
          return (<Link key={l.href} href={l.href} className={`flex flex-col items-center gap-0.5 py-2.5 text-[10px] font-extrabold ${active ? "text-brand-700" : "text-slate-500"}`}><l.icon className={`h-5 w-5 ${active ? "text-accent-500" : ""}`} />{l.label}</Link>);
        })}
      </nav>
    </>
  );
}

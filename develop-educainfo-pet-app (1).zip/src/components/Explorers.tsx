"use client";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import type { Course, Product } from "@/lib/catalog";
import { CourseCard } from "./Cards";
import ProductCard from "./ProductCard";

export function CoursesExplorer({ courses }: { courses: Course[] }) {
  const cats = ["Todos", ...Array.from(new Set(courses.map((c) => c.category)))];
  const [cat, setCat] = useState("Todos");
  const [q, setQ] = useState("");
  const filtered = useMemo(() => courses.filter((c) => (cat === "Todos" || c.category === cat) && (c.title + c.description).toLowerCase().includes(q.toLowerCase())), [courses, cat, q]);
  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">{cats.map((c) => <button key={c} onClick={() => setCat(c)} className={`rounded-full px-4 py-2 text-sm font-extrabold ${cat === c ? "bg-brand-900 text-white" : "bg-white text-slate-600 ring-1 ring-brand-100 hover:bg-brand-50"}`}>{c}</button>)}</div>
        <label className="flex items-center gap-2 rounded-full bg-white px-4 py-2.5 ring-1 ring-brand-100 sm:w-72"><Search className="h-4 w-4 text-slate-400" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar curso..." className="w-full bg-transparent text-sm font-semibold" /></label>
      </div>
      {filtered.length === 0 ? <p className="mt-10 rounded-3xl bg-white p-8 text-center font-bold text-slate-500">No encontramos cursos con ese criterio. Prueba con otra palabra.</p> :
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{filtered.map((c) => <CourseCard key={c.id} course={c} />)}</div>}
    </div>
  );
}

export function ShopExplorer({ products }: { products: Product[] }) {
  const cats = ["Todos", ...Array.from(new Set(products.map((p) => p.category)))];
  const [cat, setCat] = useState("Todos");
  const [q, setQ] = useState("");
  const filtered = useMemo(() => products.filter((p) => (cat === "Todos" || p.category === cat) && (p.name + p.description).toLowerCase().includes(q.toLowerCase())), [products, cat, q]);
  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">{cats.map((c) => <button key={c} onClick={() => setCat(c)} className={`rounded-full px-4 py-2 text-sm font-extrabold ${cat === c ? "bg-brand-900 text-white" : "bg-white text-slate-600 ring-1 ring-brand-100 hover:bg-brand-50"}`}>{c}</button>)}</div>
        <label className="flex items-center gap-2 rounded-full bg-white px-4 py-2.5 ring-1 ring-brand-100 sm:w-72"><Search className="h-4 w-4 text-slate-400" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar producto..." className="w-full bg-transparent text-sm font-semibold" /></label>
      </div>
      {filtered.length === 0 ? <p className="mt-10 rounded-3xl bg-white p-8 text-center font-bold text-slate-500">Sin resultados. Revisa la ortografía o cambia de categoría.</p> :
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{filtered.map((p) => <ProductCard key={p.id} p={p} />)}</div>}
    </div>
  );
}

import Link from "next/link";
import { Clock3, MapPin, MessageCircle, Phone, ShieldCheck } from "lucide-react";
import Logo from "./Logo";
import { ADDRESS, PHONES, WHATSAPP } from "@/lib/data";

export default function Footer() {
  return (
    <footer className="bg-brand-950 pb-24 lg:pb-0 text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-4">
        <div>
          <Logo light />
          <p className="mt-4 text-sm leading-relaxed text-brand-100">La app de EDUCAN · Escuela de Adiestramiento. Educación canina profesional, spa, peluquería y todo para tu mejor amigo, en un solo lugar.</p>
          <a href={`https://wa.me/${WHATSAPP}?text=Hola%20EDUCAN,%20quiero%20informaci%C3%B3n%20de%20EducaInfo`} target="_blank" className="mt-5 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-5 py-3 text-sm font-extrabold text-white hover:bg-emerald-600"><MessageCircle className="h-4 w-4" /> Escríbenos por WhatsApp</a>
        </div>
        <div>
          <h4 className="font-display text-lg font-semibold">Servicios</h4>
          <ul className="mt-4 space-y-2.5 text-sm font-semibold text-brand-100">
            <li><Link href="/entrenamiento" className="hover:text-accent-500">Adiestramiento online</Link></li>
            <li><Link href="/comportamiento" className="hover:text-accent-500">Asesoría de comportamiento</Link></li>
            <li><Link href="/spa" className="hover:text-accent-500">Spa y peluquería canina</Link></li>
            <li><Link href="/tienda" className="hover:text-accent-500">Concentrado y accesorios</Link></li>
            <li><Link href="/planes" className="hover:text-accent-500">Planes Premium</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-lg font-semibold">Contacto EDUCAN</h4>
          <ul className="mt-4 space-y-3 text-sm font-semibold text-brand-100">
            <li className="flex gap-2"><MapPin className="h-4 w-4 shrink-0 text-accent-500" />{ADDRESS}</li>
            {PHONES.map((p) => (<li key={p} className="flex gap-2"><Phone className="h-4 w-4 shrink-0 text-accent-500" />{p}</li>))}
            <li className="flex gap-2"><Clock3 className="h-4 w-4 shrink-0 text-accent-500" />Lun a Sáb · 8:00 am – 6:00 pm</li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-lg font-semibold">Tu prueba gratis</h4>
          <p className="mt-4 text-sm leading-relaxed text-brand-100">Regístrate y disfruta <b className="text-white">7 días de acceso total</b> a cursos de adiestramiento y guías de comportamiento. Sin tarjeta. Luego elige el plan que quieras.</p>
          <Link href="/registro" className="mt-4 inline-block rounded-full bg-accent-500 px-5 py-3 text-sm font-extrabold text-brand-950 hover:bg-accent-600">Empezar mis 7 días gratis</Link>
          <p className="mt-4 flex items-center gap-1.5 text-xs font-bold text-brand-100"><ShieldCheck className="h-4 w-4 text-emerald-400" /> Servicio a domicilio con protocolos de higiene</p>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs font-semibold text-brand-100">© {new Date().getFullYear()} EducaInfo · EDUCAN Escuela de Adiestramiento — Adiestramiento Profesional. Hecho con amor por los perros.</div>
    </footer>
  );
}

"use client";
import Link from "next/link";
import { ShoppingBag } from "lucide-react";
import type { Product } from "@/lib/catalog";
import { ProductInfo } from "./Cards";
import { useCart } from "./CartProvider";

export default function ProductCard({ p }: { p: Product }) {
  const { add } = useCart();
  return (
    <article className="group overflow-hidden rounded-3xl border border-brand-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
      <div className="relative h-52 overflow-hidden">
        <img src={p.image} alt={p.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
        {p.badge && <span className="absolute left-3 top-3 rounded-full bg-accent-500 px-3 py-1 text-[11px] font-extrabold text-brand-950">{p.badge}</span>}
      </div>
      <ProductInfo p={p} />
      <div className="flex gap-2 px-5 pb-5">
        <button onClick={() => add({ id: p.id, name: p.name, price: p.price, image: p.image })} className="flex flex-1 items-center justify-center gap-2 rounded-full bg-brand-900 py-3 text-sm font-extrabold text-white hover:bg-brand-700"><ShoppingBag className="h-4 w-4" />Agregar</button>
        <Link href="/carrito" onClick={() => add({ id: p.id, name: p.name, price: p.price, image: p.image })} className="rounded-full bg-accent-500 px-4 py-3 text-sm font-extrabold text-brand-950 hover:bg-accent-600">Comprar</Link>
      </div>
    </article>
  );
}

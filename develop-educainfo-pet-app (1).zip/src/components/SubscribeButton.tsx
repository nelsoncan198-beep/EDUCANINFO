"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Crown, Loader2 } from "lucide-react";

export default function SubscribeButton({ planId, planName, highlight, isLogged }: { planId: string; planName: string; highlight?: boolean; isLogged: boolean }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false); const [done, setDone] = useState(false); const [error, setError] = useState("");
  async function act() {
    if (!isLogged) { router.push(`/registro?next=/planes`); return; }
    setLoading(true); setError("");
    const r = await fetch("/api/subscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ planId }) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error || "Error"); return; }
    setDone(true); router.refresh();
  }
  if (done) return <p className="flex items-center justify-center gap-2 rounded-full bg-emerald-100 py-3.5 font-extrabold text-emerald-700"><CheckCircle2 className="h-5 w-5" /> ¡{planName} activo! Revisa tu cuenta</p>;
  return (
    <>
      <button onClick={act} disabled={loading} className={`flex w-full items-center justify-center gap-2 rounded-full py-3.5 font-extrabold disabled:opacity-60 ${highlight ? "bg-accent-500 text-brand-950 hover:bg-accent-600" : "bg-brand-900 text-white hover:bg-brand-700"}`}>
        {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Crown className="h-5 w-5" />} {isLogged ? `Activar plan ${planName}` : "Empezar 7 días gratis"}
      </button>
      {error && <p className="mt-2 text-center text-sm font-bold text-rose-600">{error}</p>}
    </>
  );
}

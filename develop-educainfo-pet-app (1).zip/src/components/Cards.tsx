import Link from "next/link";
import { Clock3, Layers, PlayCircle, Star } from "lucide-react";
import type { Course } from "@/lib/catalog";
import { fmtCOP } from "@/lib/format";
import type { Product } from "@/lib/catalog";

export function CourseCard({ course }: { course: Course }) {
  return (
    <Link href={`/entrenamiento/${course.slug}`} className="group overflow-hidden rounded-3xl border border-brand-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
      <div className="relative h-48 overflow-hidden">
        <img src={course.image} alt={course.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-brand-950/85 px-3 py-1 text-[11px] font-extrabold text-white">{course.category}</span>
        <span className="absolute right-3 top-3 rounded-full bg-accent-500 px-3 py-1 text-[11px] font-extrabold text-brand-950">{course.level}</span>
        <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-extrabold text-brand-800"><PlayCircle className="h-4 w-4 text-brand-600" />{course.lessons.length} lecciones</span>
      </div>
      <div className="p-5">
        <h3 className="font-display text-xl font-semibold leading-snug text-brand-950">{course.title}</h3>
        <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-slate-600">{course.description}</p>
        <div className="mt-4 flex items-center justify-between text-xs font-extrabold text-slate-500">
          <span className="inline-flex items-center gap-1"><Clock3 className="h-4 w-4" />{course.durationLabel}</span>
          <span className="inline-flex items-center gap-1"><Layers className="h-4 w-4" />1ª lección gratis</span>
        </div>
      </div>
    </Link>
  );
}

export function ProductInfo({ p }: { p: Product }) {
  return (
    <div className="p-5">
      <div className="flex items-center justify-between">
        <span className="rounded-full bg-brand-50 px-2.5 py-1 text-[11px] font-extrabold text-brand-700">{p.category}</span>
        <span className="inline-flex items-center gap-1 text-xs font-extrabold text-amber-500"><Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />{p.rating}</span>
      </div>
      <h3 className="font-display mt-3 text-lg font-semibold leading-snug text-brand-950">{p.name}</h3>
      <p className="mt-1.5 line-clamp-2 text-sm text-slate-600">{p.description}</p>
      <div className="mt-3 flex items-baseline gap-2">
        <span className="text-xl font-black text-brand-900">{fmtCOP(p.price)}</span>
        {p.oldPrice && <span className="text-sm font-bold text-slate-400 line-through">{fmtCOP(p.oldPrice)}</span>}
      </div>
      <p className={`mt-1 text-xs font-extrabold ${p.stock > 10 ? "text-emerald-600" : "text-rose-600"}`}>{p.stock > 10 ? "Disponible · envío hoy" : `¡Quedan solo ${p.stock}!`}</p>
    </div>
  );
}

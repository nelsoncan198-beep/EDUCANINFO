"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Dog, Loader2, LogOut, Plus, Trash2 } from "lucide-react";

export type DogRow = { id: number; name: string; breed: string; ageLabel: string; size: string; behaviorNotes: string };
const inputCls = "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold";

export function LogoutButton() {
  const router = useRouter();
  async function out() { await fetch("/api/auth/logout", { method: "POST" }); router.push("/"); router.refresh(); }
  return <button onClick={out} className="inline-flex items-center gap-2 rounded-full bg-rose-50 px-5 py-2.5 text-sm font-extrabold text-rose-600 hover:bg-rose-100"><LogOut className="h-4 w-4" /> Cerrar sesión</button>;
}

export default function DogManager({ initialDogs }: { initialDogs: DogRow[] }) {
  const router = useRouter();
  const [dogs, setDogs] = useState(initialDogs);
  const [form, setForm] = useState({ name: "", breed: "", ageLabel: "", size: "Mediano", behaviorNotes: "" });
  const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  async function add(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const r = await fetch("/api/dogs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error); return; }
    setDogs([...dogs, d.dog]); setForm({ name: "", breed: "", ageLabel: "", size: "Mediano", behaviorNotes: "" }); router.refresh();
  }
  async function del(id: number) { await fetch(`/api/dogs/${id}`, { method: "DELETE" }); setDogs(dogs.filter((d) => d.id !== id)); router.refresh(); }
  return (
    <div>
      {dogs.length === 0 && <p className="rounded-2xl bg-brand-50 px-5 py-4 text-sm font-bold text-brand-800">Aún no registras a tu perro. Agrega el primero y personaliza su ruta de aprendizaje.</p>}
      <div className="grid gap-4 sm:grid-cols-2">
        {dogs.map((d) => (
          <article key={d.id} className="rounded-3xl border border-brand-100 bg-white p-5">
            <div className="flex items-start justify-between">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-900 text-white"><Dog className="h-6 w-6" /></span>
              <button onClick={() => del(d.id)} className="grid h-9 w-9 place-items-center rounded-full bg-rose-50 text-rose-500" aria-label="Eliminar"><Trash2 className="h-4 w-4" /></button>
            </div>
            <h3 className="font-display mt-3 text-xl font-semibold text-brand-950">{d.name}</h3>
            <p className="text-sm font-semibold text-slate-500">{[d.breed, d.ageLabel, d.size].filter(Boolean).join(" · ") || "Sin datos adicionales"}</p>
            {d.behaviorNotes && <p className="mt-2 rounded-xl bg-cream px-3 py-2 text-[13px] font-semibold text-slate-600">{d.behaviorNotes}</p>}
          </article>
        ))}
      </div>
      <form onSubmit={add} className="mt-5 rounded-3xl bg-brand-50 p-5">
        <p className="font-display text-lg font-semibold text-brand-950">Agregar otro perro</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <input required className={inputCls} placeholder="Nombre *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className={inputCls} placeholder="Raza" value={form.breed} onChange={(e) => setForm({ ...form, breed: e.target.value })} />
          <input className={inputCls} placeholder="Edad (ej. 4 meses, 2 años)" value={form.ageLabel} onChange={(e) => setForm({ ...form, ageLabel: e.target.value })} />
          <select className={inputCls} value={form.size} onChange={(e) => setForm({ ...form, size: e.target.value })}>{["Pequeño", "Mediano", "Grande", "Gigante"].map((s) => <option key={s}>{s}</option>)}</select>
          <input className={`${inputCls} sm:col-span-2`} placeholder="¿Qué quieres mejorar? (tira de la correa, ladra, es cachorro...)" value={form.behaviorNotes} onChange={(e) => setForm({ ...form, behaviorNotes: e.target.value })} />
        </div>
        {error && <p className="mt-2 text-sm font-bold text-rose-600">{error}</p>}
        <button disabled={loading} className="mt-4 inline-flex items-center gap-2 rounded-full bg-brand-900 px-6 py-3 text-sm font-extrabold text-white hover:bg-brand-700 disabled:opacity-60">{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Agregar perro</button>
      </form>
    </div>
  );
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CalendarCheck2, CheckCircle2, HeartHandshake, Loader2, MessageCircle } from "lucide-react";
import { WHATSAPP } from "@/lib/data";
import { fmtCOP } from "@/lib/format";

const inputCls = "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold placeholder:font-normal";

export function BookingForm({ services, userName = "", userPhone = "" }: { services: { name: string; price: number }[]; userName?: string; userPhone?: string }) {
  const [form, setForm] = useState({ customerName: userName, phone: userPhone, dogName: "", serviceName: services[0]?.name || "", date: "", time: "09:00", mode: "sede", notes: "" });
  const [loading, setLoading] = useState(false); const [done, setDone] = useState<{ id: number; wa: string } | null>(null); const [error, setError] = useState("");
  const sel = services.find((s) => s.name === form.serviceName);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const r = await fetch("/api/bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error || "Error al reservar"); return; }
    setDone({ id: d.booking.id, wa: d.whatsapp });
  }
  if (done) return (
    <div className="rounded-3xl bg-emerald-50 p-6 text-center ring-1 ring-emerald-200">
      <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-500" />
      <h3 className="font-display mt-3 text-2xl font-semibold text-emerald-900">¡Reserva #{done.id} recibida!</h3>
      <p className="mt-2 text-sm font-semibold text-emerald-800">Te confirmaremos por WhatsApp. Si quieres agilizar, envíanos el comprobante de tu reserva:</p>
      <a target="_blank" href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(done.wa)}`} className="mt-4 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-6 py-3 font-extrabold text-white hover:bg-emerald-600"><MessageCircle className="h-5 w-5" /> Confirmar por WhatsApp</a>
      <button onClick={() => setDone(null)} className="mt-3 block w-full text-sm font-extrabold text-emerald-700">Hacer otra reserva</button>
    </div>
  );
  return (
    <form onSubmit={submit} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-brand-100">
      <h3 className="font-display flex items-center gap-2 text-2xl font-semibold text-brand-950"><CalendarCheck2 className="h-6 w-6 text-brand-600" /> Reserva tu cita</h3>
      <p className="mt-1 text-sm text-slate-500">Confirmamos por WhatsApp en menos de 30 minutos en horario laboral.</p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <input required className={inputCls} placeholder="Tu nombre" value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} />
        <input required className={inputCls} placeholder="WhatsApp (ej. 3161234567)" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <input required className={inputCls} placeholder="Nombre de tu perro" value={form.dogName} onChange={(e) => setForm({ ...form, dogName: e.target.value })} />
        <select className={inputCls} value={form.serviceName} onChange={(e) => setForm({ ...form, serviceName: e.target.value })}>{services.map((s) => <option key={s.name} value={s.name}>{s.name} — {fmtCOP(s.price)}</option>)}</select>
        <input required type="date" className={inputCls} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
        <select className={inputCls} value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })}>{["08:00", "09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"].map((t) => <option key={t}>{t}</option>)}</select>
        <div className="grid grid-cols-2 gap-2 sm:col-span-2">
          {[["sede", "En sede EDUCAN"], ["domicilio", "A domicilio"]].map(([v, l]) => (
            <button type="button" key={v} onClick={() => setForm({ ...form, mode: v })} className={`rounded-xl py-3 text-sm font-extrabold ${form.mode === v ? "bg-brand-900 text-white" : "bg-brand-50 text-slate-600"}`}>{l}</button>
          ))}
        </div>
        <textarea className={`${inputCls} sm:col-span-2`} rows={2} placeholder="Notas: raza, tamaño, alergias, comportamiento..." value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </div>
      {sel && <p className="mt-3 rounded-xl bg-cream px-4 py-3 text-sm font-extrabold text-brand-900">Total a pagar al recibir el servicio: {fmtCOP(sel.price)} {form.mode === "domicilio" ? "· transporte incluido en zona" : ""}</p>}
      {error && <p className="mt-3 rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-600">{error}</p>}
      <button disabled={loading} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-accent-500 py-4 font-extrabold text-brand-950 hover:bg-accent-600 disabled:opacity-60">{loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <CalendarCheck2 className="h-5 w-5" />} Confirmar reserva</button>
    </form>
  );
}

export function ConsultationForm({ userName = "", userPhone = "" }: { userName?: string; userPhone?: string }) {
  const [form, setForm] = useState({ name: userName, phone: userPhone, dogName: "", issue: "" });
  const [loading, setLoading] = useState(false); const [done, setDone] = useState(false); const [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const r = await fetch("/api/consultations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error); return; } setDone(true);
  }
  if (done) return (
    <div className="rounded-3xl bg-emerald-50 p-6 text-center ring-1 ring-emerald-200">
      <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-500" />
      <h3 className="font-display mt-3 text-2xl font-semibold text-emerald-900">¡Caso recibido!</h3>
      <p className="mt-2 text-sm font-semibold text-emerald-800">Un adiestrador EDUCAN revisará el caso de {form.dogName || "tu perro"} y te contactará por WhatsApp para agendar la asesoría.</p>
      <a target="_blank" href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(`Hola EDUCAN, soy ${form.name}. Solicité asesoría de comportamiento para ${form.dogName}: ${form.issue}`)}`} className="mt-4 inline-flex items-center gap-2 rounded-full bg-emerald-500 px-6 py-3 font-extrabold text-white"><MessageCircle className="h-5 w-5" /> Contar mi caso por WhatsApp</a>
    </div>
  );
  return (
    <form onSubmit={submit} className="rounded-3xl bg-brand-950 p-6 text-white shadow-xl">
      <h3 className="font-display flex items-center gap-2 text-2xl font-semibold"><HeartHandshake className="h-6 w-6 text-accent-500" /> Cuéntanos tu caso</h3>
      <p className="mt-1 text-sm text-brand-100">Evaluación inicial sin costo. Te respondemos el mismo día.</p>
      <div className="mt-5 grid gap-3">
        <input required className={inputCls + " text-slate-900"} placeholder="Tu nombre" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input required className={inputCls + " text-slate-900"} placeholder="Tu WhatsApp" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <input className={inputCls + " text-slate-900"} placeholder="Nombre y raza de tu perro" value={form.dogName} onChange={(e) => setForm({ ...form, dogName: e.target.value })} />
        <div className="flex flex-wrap gap-2">{["Ansiedad al quedarse solo", "Ladra mucho", "Tira de la correa", "Miedos / pólvora", "Agresividad", "Destruye cosas"].map((i) => <button type="button" key={i} onClick={() => setForm({ ...form, issue: i })} className={`rounded-full px-3 py-1.5 text-xs font-extrabold ${form.issue === i ? "bg-accent-500 text-brand-950" : "bg-white/10 text-white ring-1 ring-white/20"}`}>{i}</button>)}</div>
        <textarea required rows={3} className={inputCls + " text-slate-900"} placeholder="Describe el comportamiento: ¿desde cuándo?, ¿en qué momentos?, ¿qué has intentado?" value={form.issue} onChange={(e) => setForm({ ...form, issue: e.target.value })} />
      </div>
      {error && <p className="mt-3 rounded-xl bg-rose-500/20 px-4 py-3 text-sm font-bold text-rose-200">{error}</p>}
      <button disabled={loading} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-accent-500 py-4 font-extrabold text-brand-950 hover:bg-accent-600 disabled:opacity-60">{loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <HeartHandshake className="h-5 w-5" />} Solicitar asesoría gratuita</button>
    </form>
  );
}

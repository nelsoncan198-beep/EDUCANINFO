"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, ChevronDown, Clock3, Lock, PlayCircle, Circle } from "lucide-react";
import type { Lesson } from "@/lib/catalog";

export default function LessonList({ lessons, completedIds, hasAccess, isLogged }: { lessons: Lesson[]; completedIds: number[]; hasAccess: boolean; isLogged: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState<number | null>(lessons[0]?.id ?? null);
  const [done, setDone] = useState<number[]>(completedIds);
  const [busy, setBusy] = useState<number | null>(null);

  async function toggle(lesson: Lesson) {
    if (!isLogged) { router.push("/registro"); return; }
    const isDone = done.includes(lesson.id);
    setBusy(lesson.id);
    const r = await fetch("/api/progress", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lessonId: lesson.id, completed: !isDone }) });
    setBusy(null);
    if (r.ok) setDone(isDone ? done.filter((d) => d !== lesson.id) : [...done, lesson.id]);
  }

  return (
    <div className="space-y-3">
      {lessons.map((l, i) => {
        const unlocked = l.isPreview || hasAccess;
        const isDone = done.includes(l.id);
        const isOpen = open === l.id;
        return (
          <article key={l.id} className={`overflow-hidden rounded-3xl border bg-white ${isDone ? "border-emerald-200" : "border-brand-100"}`}>
            <button onClick={() => unlocked && setOpen(isOpen ? null : l.id)} className="flex w-full items-center gap-4 px-5 py-4 text-left">
              <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-full ${isDone ? "bg-emerald-100 text-emerald-600" : unlocked ? "bg-brand-900 text-white" : "bg-slate-100 text-slate-400"}`}>
                {isDone ? <CheckCircle2 className="h-5 w-5" /> : unlocked ? <PlayCircle className="h-5 w-5" /> : <Lock className="h-5 w-5" />}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[11px] font-extrabold uppercase tracking-widest text-slate-400">Lección {i + 1} {l.isPreview && <span className="text-emerald-600">· Vista previa gratis</span>}</span>
                <span className="font-display block truncate text-lg font-semibold text-brand-950">{l.title}</span>
                <span className="flex items-center gap-1 text-xs font-bold text-slate-500"><Clock3 className="h-3.5 w-3.5" />{l.durationMin} min de práctica</span>
              </span>
              {unlocked ? <ChevronDown className={`h-5 w-5 shrink-0 text-slate-400 transition ${isOpen ? "rotate-180" : ""}`} /> : <span className="shrink-0 rounded-full bg-accent-100 px-3 py-1 text-[11px] font-extrabold text-accent-600">Premium</span>}
            </button>
            {isOpen && unlocked && (
              <div className="border-t border-brand-50 px-5 py-5">
                <p className="font-semibold text-slate-700">{l.description}</p>
                <h4 className="mt-4 text-xs font-extrabold uppercase tracking-widest text-brand-600">Guía paso a paso de hoy</h4>
                <ol className="mt-3 space-y-3">
                  {l.steps.map((s, j) => (
                    <li key={j} className="flex gap-3"><span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-brand-900 text-xs font-black text-white">{j + 1}</span><p className="text-sm leading-relaxed text-slate-600">{s}</p></li>
                  ))}
                </ol>
                <div className="mt-5 flex flex-wrap gap-2">
                  <button onClick={() => toggle(l)} disabled={busy === l.id} className={`inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-extrabold ${isDone ? "bg-emerald-100 text-emerald-700" : "bg-brand-900 text-white hover:bg-brand-700"}`}>
                    {isDone ? <CheckCircle2 className="h-4 w-4" /> : <Circle className="h-4 w-4" />}{isDone ? "Lección completada" : "Marcar como completada"}
                  </button>
                  {!isLogged && <span className="self-center text-sm font-bold text-slate-500">Crea tu cuenta gratis para guardar el progreso</span>}
                </div>
              </div>
            )}
            {!unlocked && (
              <div className="border-t border-brand-50 bg-cream px-5 py-4">
                <p className="text-sm font-semibold text-slate-600">{isLogged ? "Esta lección se desbloquea con tu prueba gratuita activa o con Premium." : "Crea tu cuenta y actívala con 7 días gratis para ver esta lección."}</p>
                <Link href={isLogged ? "/planes" : "/registro"} className="mt-2 inline-block rounded-full bg-accent-500 px-5 py-2.5 text-sm font-extrabold text-brand-950">{isLogged ? "Activar Premium" : "Crear cuenta gratis"}</Link>
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}

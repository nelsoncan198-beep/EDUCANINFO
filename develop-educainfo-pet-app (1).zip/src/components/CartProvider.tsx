"use client";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type CartItem = { id: number; name: string; price: number; image: string; qty: number };
type CartCtx = { items: CartItem[]; count: number; total: number; add: (i: Omit<CartItem, "qty">) => void; remove: (id: number) => void; setQty: (id: number, q: number) => void; clear: () => void; toast: string };
const Ctx = createContext<CartCtx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [toast, setToast] = useState("");
  useEffect(() => { try { setItems(JSON.parse(localStorage.getItem("educainfo_cart") || "[]")); } catch {} }, []);
  useEffect(() => { localStorage.setItem("educainfo_cart", JSON.stringify(items)); }, [items]);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(""), 2600); return () => clearTimeout(t); }, [toast]);

  const add: CartCtx["add"] = (item) => {
    setItems((prev) => { const f = prev.find((p) => p.id === item.id); return f ? prev.map((p) => p.id === item.id ? { ...p, qty: p.qty + 1 } : p) : [...prev, { ...item, qty: 1 }]; });
    setToast(`Agregado: ${item.name}`);
  };
  const remove = (id: number) => setItems((p) => p.filter((i) => i.id !== id));
  const setQty = (id: number, q: number) => setItems((p) => q <= 0 ? p.filter((i) => i.id !== id) : p.map((i) => i.id === id ? { ...i, qty: q } : i));
  const clear = () => setItems([]);
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  return (
    <Ctx.Provider value={{ items, count: items.reduce((s, i) => s + i.qty, 0), total, add, remove, setQty, clear, toast }}>
      {children}
      {toast && <div className="fixed bottom-24 md:bottom-6 left-1/2 z-[80] -translate-x-1/2 rounded-full bg-brand-950 px-5 py-3 text-sm font-bold text-white shadow-2xl">{toast}</div>}
    </Ctx.Provider>
  );
}
export function useCart() { const c = useContext(Ctx); if (!c) throw new Error("cart"); return c; }

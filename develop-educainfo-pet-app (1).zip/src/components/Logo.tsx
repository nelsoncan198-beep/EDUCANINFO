import { PawPrint } from "lucide-react";
import Link from "next/link";

export default function Logo({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2.5 shrink-0">
      <span className="relative grid h-11 w-11 place-items-center rounded-full bg-accent-500 ring-4 ring-white/90 shadow-md">
        <PawPrint className="h-6 w-6 text-brand-950" strokeWidth={2.4} />
        <span className="absolute -bottom-1 -right-1 grid h-4 w-4 place-items-center rounded-full bg-brand-600 ring-2 ring-white text-[8px] font-black text-white">E</span>
      </span>
      {!compact && (
        <span className="leading-none">
          <span className={`font-display block text-[22px] font-700 font-bold tracking-tight ${light ? "text-white" : "text-brand-900"}`}>
            Educa<span className="text-accent-500">Info</span>
          </span>
          <span className={`block text-[9px] font-extrabold tracking-[0.22em] uppercase ${light ? "text-brand-100" : "text-brand-600"}`}>by EDUCAN · Escuela Canina</span>
        </span>
      )}
    </Link>
  );
}

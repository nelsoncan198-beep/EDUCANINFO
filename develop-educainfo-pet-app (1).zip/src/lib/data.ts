export const PHONES = ["316 282 6043", "316 282 6046", "323 552 0924"];
export const ADDRESS = "Carrera 26 # 10-34, San Felipe";
export const WHATSAPP = "573162826043";

export const IMG = {
  hero: "https://images.pexels.com/photos/5255554/pexels-photo-5255554.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  training: "https://images.pexels.com/photos/17786595/pexels-photo-17786595.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  advanced: "https://images.pexels.com/photos/15322829/pexels-photo-15322829.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  agility: "https://images.pexels.com/photos/11720151/pexels-photo-11720151.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  puppy: "https://images.pexels.com/photos/27434756/pexels-photo-27434756.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  walk: "https://images.pexels.com/photos/7296943/pexels-photo-7296943.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  shepherd: "https://images.pexels.com/photos/35193924/pexels-photo-35193924.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  spa1: "https://images.pexels.com/photos/19145883/pexels-photo-19145883.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  spa2: "https://images.pexels.com/photos/19145897/pexels-photo-19145897.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  spa3: "https://images.pexels.com/photos/6131161/pexels-photo-6131161.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  food1: "https://images.pexels.com/photos/6568944/pexels-photo-6568944.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  food2: "https://images.pexels.com/photos/8434670/pexels-photo-8434670.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  food3: "https://images.pexels.com/photos/5482828/pexels-photo-5482828.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
};

export type SeedLesson = { title: string; description: string; durationMin: number; isPreview: boolean; steps: string[] };
export type SeedCourse = { slug: string; title: string; description: string; level: string; category: string; durationLabel: string; image: string; lessons: SeedLesson[] };

export const seedCourses: SeedCourse[] = [
  {
    slug: "cachorros-bases-solidas", title: "Cachorros con bases sólidas",
    description: "Socialización, rutinas, control de mordida y los primeros comandos para criar un perro equilibrado desde los 2 meses.",
    level: "Inicial", category: "Cachorros", durationLabel: "2 semanas · 10 min/día", image: IMG.puppy,
    lessons: [
      { title: "Bienvenida y socialización segura", description: "Cómo presentarle el mundo a tu cachorro sin crearle miedos.", durationMin: 9, isPreview: true, steps: ["Expón a tu cachorro a sonidos, personas y superficies nuevas de forma gradual, siempre con premios.", "Nunca lo obligues a acercarse: deja que él decida y refuerza cada avance con comida de alto valor.", "Crea una 'caja de experiencias': 5 estímulos nuevos al día durante la etapa de socialización (8-16 semanas).", "Termina cada exposición con juego tranquilo para asociar lo nuevo con algo positivo."] },
      { title: "Su nombre y la atención voluntaria", description: "Logra que tu cachorro te mire cuando lo llamas, la base de todo el adiestramiento.", durationMin: 8, isPreview: false, steps: ["Di su nombre una sola vez y, cuando gire a mirarte, marca con '¡sí!' y premia.", "Repite 10 veces en un lugar sin distracciones y luego sube la dificultad poco a poco.", "Nunca uses su nombre para regañarlo: debe significar siempre algo bueno."] },
      { title: "Sentado, echado y control de mordida", description: "Primeros comandos y cómo enseñarle a inhibir la mordida jugando.", durationMin: 12, isPreview: false, steps: ["Guía el premio desde su nariz hacia atrás para provocar el sentado; marca y recompensa.", "Para el echado, baja el premio entre sus patas delanteras lentamente.", "Si muerde manos, detén el juego 10 segundos: aprende que morder fuerte termina la diversión."] },
      { title: "Rutina de baño, cepillado y descanso", description: "Hábitos de higiene y sueño para un cachorro tranquilo en casa.", durationMin: 10, isPreview: false, steps: ["Asocia el cepillo y el agua con premios desde el primer día, sin bañarlo completo aún.", "Define un lugar de descanso y respeta sus siestas: un cachorro duerme 16-18 horas.", "Crea rutina fija de comidas, juego y salidas: la previsibilidad reduce la ansiedad."] },
    ],
  },
  {
    slug: "obediencia-basica-casa-calle", title: "Obediencia básica en casa y en la calle",
    description: "Sentado, quieto, venida y autocontrol frente a comida y visitas. El curso esencial de EDUCAN para toda la familia.",
    level: "Inicial", category: "Obediencia", durationLabel: "3 semanas · 15 min/día", image: IMG.training,
    lessons: [
      { title: "El marcador: cómo comunicarte con tu perro", description: "La palabra puente que hace que tu perro entienda exactamente qué hizo bien.", durationMin: 7, isPreview: true, steps: ["Elige una palabra corta ('sí') o un clicker y cárgala: marcador → premio, 20 repeticiones.", "El premio debe llegar en menos de 1 segundo después del marcador.", "Usa el marcador solo para entrenar: no lo gastes en la vida diaria."] },
      { title: "Sentado y quieto con duración", description: "Construye permanencias reales paso a paso sin frustrar a tu perro.", durationMin: 13, isPreview: false, steps: ["Pide el sentado, espera 2 segundos, marca y premia. Sube de 2 en 2 segundos.", "Añade distancia de un paso y regresa siempre a premiar junto a él.", "Si se levanta, no regañes: baja el criterio y vuelve a construir."] },
      { title: "La venida infalible (recall)", description: "Que venga cuando lo llamas, incluso con distracciones.", durationMin: 14, isPreview: false, steps: ["Empieza en casa con premios extraordinarios: pollo, salchicha o queso.", "Nunca llames a tu perro para algo negativo (baño, fin del parque).", "Juega al 'ping-pong': dos personas lo llaman por turnos y cada venida es una fiesta."] },
      { title: "Autocontrol: comida, puerta y visitas", description: "Un perro que espera es un perro seguro.", durationMin: 12, isPreview: false, steps: ["Ejercicio 'es tu elección': premio en la mano cerrada; solo se abre si se aleja.", "Practica la espera en la puerta antes de cada paseo, 30 segundos.", "Con visitas, premia la calma en su cama antes de saludar."] },
    ],
  },
  {
    slug: "paseo-sin-tirones", title: "Paseo sin tirones",
    description: "Convierte el paseo en el mejor momento del día: sin jalones, sin estrés y con conexión real con tu perro.",
    level: "Intermedio", category: "Paseo", durationLabel: "2 semanas · 20 min/día", image: IMG.walk,
    lessons: [
      { title: "Por qué tira y cómo piensa tu perro en el paseo", description: "Entiende la motivación antes de corregir el síntoma.", durationMin: 8, isPreview: true, steps: ["El perro tira porque funciona: tirar lo acerca a lo que quiere oler.", "El paseo ideal combina caminata junto a ti y momentos libres de olfateo.", "Revisa el equipo: arnés en 'Y' y correa de 2-3 metros dan aprendizaje sin dolor."] },
      { title: "Caminar junto a ti en lugares tranquilos", description: "La técnica del paso a paso con refuerzo frecuente.", durationMin: 15, isPreview: false, steps: ["Premia cada vez que tu perro quede a tu lado y te mire: al inicio cada 2-3 pasos.", "Cambia de dirección cuando la correa se tense, sin tirones.", "Sesiones cortas de 5 minutos valen más que una hora de lucha."] },
      { title: "Cruces, perros y distracciones reales", description: "Generaliza lo aprendido en la calle paso a paso.", durationMin: 16, isPreview: false, steps: ["Trabaja a la distancia donde tu perro sí puede pensar; acércate gradualmente.", "Usa el ejercicio 'mira eso': ver la distracción y volver a mirarte = premio grande.", "Planea rutas progresivas: calle tranquila → parque → zona concurrida."] },
      { title: "El paseo perfecto: estructura y libertad", description: "Cómo combinar reglas y olfateo libre en cada salida.", durationMin: 11, isPreview: false, steps: ["Alterna bloques: 5 min junto a ti, 3 min de olfateo libre con palabra clave ('libre').", "El olfateo reduce el estrés tanto como el ejercicio físico.", "Termina el paseo con un comando conocido y un premio: cierre positivo siempre."] },
    ],
  },
  {
    slug: "ansiedad-miedos-ladridos", title: "Ansiedad, miedos y ladridos",
    description: "Asesoría de comportamiento aplicada: protocolos paso a paso para los problemas más comunes en casa.",
    level: "Intermedio", category: "Comportamiento", durationLabel: "4 semanas · guía diaria", image: IMG.shepherd,
    lessons: [
      { title: "Ansiedad por separación: el protocolo completo", description: "Salidas graduales para que tu perro se quede solo y tranquilo.", durationMin: 18, isPreview: true, steps: ["Salidas falsas de segundos que crecen muy gradualmente, sin superar su umbral.", "Desensibiliza las señales de partida: llaves, zapatos y bolso sin salir.", "Deja trabajo mental (juguetes rellenos congelados) solo cuando te vas.", "Graba con el celular para medir progreso real, no suposiciones."] },
      { title: "Ladridos excesivos: causa y solución", description: "No todos los ladridos se tratan igual: identifica el tipo y actúa.", durationMin: 14, isPreview: false, steps: ["Clasifica: alerta, demanda, aburrimiento, miedo o territorial.", "Enseña 'silencio' premiando los segundos sin ladrar frente al estímulo.", "Un perro cansado física y mentalmente ladra menos: revisa su rutina."] },
      { title: "Miedo a la pólvora y a los truenos", description: "Plan de desensibilización y manejo para temporadas de fiesta.", durationMin: 15, isPreview: false, steps: ["Reproduce sonidos de pólvora a volumen mínimo asociado a comida, subiendo muy lento.", "Crea un refugio seguro con su cama, manta y música relajante.", "El día del evento: paseo temprano, casa cerrada y nunca castigar el miedo."] },
      { title: "Reactividad con correa: primer abordaje", description: "Cuando tu perro 'explota' al ver otros perros en la calle.", durationMin: 17, isPreview: false, steps: ["Identifica su distancia de reacción y trabaja siempre por debajo de ella.", "Aplica el patrón ver-mirar-premio para cambiar la emoción, no solo la conducta.", "Si hay riesgo de agresión, agenda asesoría presencial: la seguridad va primero."] },
    ],
  },
  {
    slug: "obediencia-avanzada-autocontrol", title: "Obediencia avanzada y autocontrol",
    description: "Para perros que ya dominan lo básico: trabajo a distancia, distracciones fuertes y deportes caninos.",
    level: "Avanzado", category: "Obediencia", durationLabel: "4 semanas · nivel EDUCAN Pro", image: IMG.advanced,
    lessons: [
      { title: "Quieto a distancia y con distracciones", description: "Permanencias de nivel competencia paso a paso.", durationMin: 16, isPreview: true, steps: ["Sube solo una variable a la vez: duración, distancia o distracción.", "Usa una plataforma o cama como 'base' para dar claridad al ejercicio.", "Refuerza con premios sorpresa de altísimo valor en los momentos difíciles."] },
      { title: "Vuelta y echado a distancia", description: "Comandos que responden aunque estés a 20 metros.", durationMin: 15, isPreview: false, steps: ["Construye cadena hacia atrás: primero el final del ejercicio, luego el inicio.", "Señal visual clara antes de la verbal para aprovechar su lenguaje corporal.", "Practica en 3 lugares distintos antes de subir distancia."] },
      { title: "Introducción a la agilidad y al juego estructurado", description: "Canaliza la energía con deporte y reglas claras de juego.", durationMin: 18, isPreview: false, steps: ["El juego también se entrena: 'suelta' y 'trae' con intercambio de juguetes.", "Saltos bajos y túnel solo con superficie segura y sin forzar articulaciones jóvenes.", "Cierra cada sesión con el perro queriendo más: motivación para mañana."] },
      { title: "Perro equilibrado en ciudad", description: "Cafés, transporte y espacios públicos sin estrés.", durationMin: 14, isPreview: false, steps: ["Practica 'a tu cama' en casa y traslada la misma manta a espacios públicos.", "Premia ignorar estímulos: la calma también es un comportamiento entrenable.", "Respeta los tiempos de descanso: la sobreexposición crea perros reactivos."] },
    ],
  },
  {
    slug: "socializacion-convivencia-multiespecie", title: "Convivencia: niños, visitas y otros animales",
    description: "Reglas de oro para hogares con niños, gatos u otros perros. Armonía real en casa.",
    level: "Todos los niveles", category: "Convivencia", durationLabel: "2 semanas · familiar", image: IMG.agility,
    lessons: [
      { title: "Perros y niños: seguridad ante todo", description: "Presentaciones correctas y señales de incomodidad que debes conocer.", durationMin: 13, isPreview: true, steps: ["Ningún niño abraza ni se acuesta sobre el perro: se acaricia de lado, 3 segundos y se espera.", "Aprende las señales de estrés: lamerse, bostezar, mostrar el blanco del ojo.", "Crea una zona sagrada donde el perro descansa y nadie lo molesta."] },
      { title: "Dos perros en casa sin conflictos", description: "Recursos, espacios y rutinas para evitar peleas.", durationMin: 12, isPreview: false, steps: ["Comidas separadas y juguetes de alto valor solo bajo supervisión.", "Cada perro necesita paseos individuales además de los conjuntos.", "Refuerza los momentos de calma compartida con premios para ambos."] },
      { title: "Perro y gato: presentación paso a paso", description: "El método de puertas, olores y recompensas que sí funciona.", durationMin: 11, isPreview: false, steps: ["Primero intercambio de olores con mantas durante varios días.", "Encuentros visuales tras una puerta de vidrio o reja, siempre premiando la calma.", "Nunca persigas correcciones: si hay tensión, aumenta la distancia y repite mañana."] },
    ],
  },
];

export const seedServices = [
  { slug: "bano-spa-completo", name: "Baño Spa Completo", type: "spa", price: 45000, durationMin: 90, image: IMG.spa1, description: "Baño con shampoo dermatológico, masaje relajante, secado, cepillado, limpieza de oídos y corte de uñas.", includes: ["Shampoo según tipo de piel", "Masaje y aromaterapia suave", "Limpieza de oídos", "Corte y limado de uñas", "Perfume hipoalergénico"], homeService: true },
  { slug: "peluqueria-profesional", name: "Peluquería Canina Profesional", type: "peluqueria", price: 60000, durationMin: 120, image: IMG.spa2, description: "Corte según raza o estilo que elijas, deslanado y acabado profesional. Tu perro, de portada.", includes: ["Corte de raza o personalizado", "Baño previo incluido", "Deslanado y desenredo", "Hidratación de almohadillas", "Foto de antes y después"], homeService: true },
  { slug: "spa-a-domicilio", name: "Spa y Peluquería a Domicilio", type: "spa", price: 75000, durationMin: 120, image: IMG.spa3, description: "Llevamos el spa a tu casa sin costo adicional de transporte en la zona. Ideal para perros nerviosos.", includes: ["Sin jaulas ni esperas", "Productos profesionales incluidos", "Mismo personal de confianza", "Reporte con fotos por WhatsApp"], homeService: true },
  { slug: "asesoria-comportamiento", name: "Asesoría de Comportamiento", type: "comportamiento", price: 90000, durationMin: 60, image: IMG.training, description: "Evaluación completa del caso (ansiedad, ladridos, miedos, reactividad) y plan de trabajo escrito para tu familia.", includes: ["Evaluación en sede o domicilio", "Plan escrito paso a paso", "Seguimiento por WhatsApp 7 días", "Sesión de revisión a mitad de precio"], homeService: true },
  { slug: "sesion-adiestramiento", name: "Sesión de Adiestramiento Presencial", type: "adiestramiento", price: 80000, durationMin: 60, image: IMG.advanced, description: "Clase personalizada con adiestradores EDUCAN: obediencia, paseo o el objetivo que tu perro necesite.", includes: ["Adiestrador profesional certificado", "Trabajo con toda la familia", "Tareas claras para la semana", "Acceso al curso online relacionado"], homeService: true },
  { slug: "guarderia-educativa", name: "Guardería Educativa (día)", type: "adiestramiento", price: 55000, durationMin: 480, image: IMG.agility, description: "Un día de socialización supervisada, juegos estructurados y refuerzo de buenos modales mientras trabajas.", includes: ["Socialización supervisada", "2 paseos y juegos estructurados", "Refuerzo de comandos básicos", "Reporte diario con fotos"], homeService: false },
];

export const seedProducts = [
  { slug: "concentrado-premium-adulto-15kg", name: "Concentrado Premium Adulto 15 kg", description: "Proteína de pollo y salmón, sin colorantes. Pelo brillante y digestión sana para perros adultos.", category: "Concentrado", price: 189900, oldPrice: 219900, image: IMG.food1, badge: "Más vendido", stock: 24, rating: "4.9" },
  { slug: "concentrado-cachorro-8kg", name: "Concentrado Cachorros 8 kg", description: "Con DHA para desarrollo cerebral y calcio controlado para huesos fuertes en crecimiento.", category: "Concentrado", price: 129900, oldPrice: 149900, image: IMG.food2, badge: "Cachorros", stock: 31, rating: "4.8" },
  { slug: "concentrado-razas-pequenas-7kg", name: "Concentrado Razas Pequeñas 7 kg", description: "Croqueta pequeña, alta palatabilidad y apoyo dental para razas mini y pequeñas.", category: "Concentrado", price: 109900, oldPrice: null, image: IMG.food3, badge: "", stock: 18, rating: "4.7" },
  { slug: "arnes-antitirones", name: "Arnés Antitirones EDUCAN", description: "Arnés en Y con doble enganche, recomendado en nuestros cursos de paseo sin tirones.", category: "Accesorios", price: 69000, oldPrice: 85000, image: IMG.walk, badge: "Recomendado", stock: 40, rating: "4.9" },
  { slug: "correa-entrenamiento-3m", name: "Correa de Entrenamiento 3 m", description: "Longitud ideal para practicar venida y paseo estructurado. Material resistente y lavable.", category: "Accesorios", price: 45000, oldPrice: null, image: IMG.training, badge: "", stock: 55, rating: "4.8" },
  { slug: "juguete-rellenable", name: "Juguete Rellenable Anti-ansiedad", description: "Rellénalo y congélalo: la herramienta #1 contra la ansiedad por separación y el aburrimiento.", category: "Accesorios", price: 39000, oldPrice: 48000, image: IMG.puppy, badge: "Anti-estrés", stock: 62, rating: "4.9" },
  { slug: "premios-entrenamiento", name: "Premios de Entrenamiento 500 g", description: "Bocados pequeños y aromáticos que no interrumpen la sesión. Los que usamos en clase.", category: "Concentrado", price: 28000, oldPrice: null, image: IMG.shepherd, badge: "", stock: 80, rating: "4.8" },
  { slug: "shampoo-dermatologico", name: "Shampoo Dermatológico Spa 500 ml", description: "El mismo de nuestro spa: pH balanceado, avena y aloe para pieles sensibles.", category: "Cuidado", price: 36000, oldPrice: 42000, image: IMG.spa3, badge: "Spa en casa", stock: 37, rating: "4.7" },
];

export const seedArticles = [
  { slug: "ansiedad-por-separacion-guia", title: "Ansiedad por separación: guía práctica para empezar hoy", category: "Ansiedad", excerpt: "Destruye, ladra o no come cuando sales. No es venganza: es pánico. Así se trabaja, paso a paso.", readMin: 7, image: IMG.shepherd, content: ["La ansiedad por separación es un trastorno de pánico: tu perro no 'se porta mal', la pasa realmente mal. Los signos clásicos son ladridos o aullidos al quedarse solo, destrucción en puertas y ventanas, babeo y negativa a comer.", "El trabajo consiste en salidas graduales: sal y vuelve antes de que entre en pánico, aunque al inicio sean solo 5 segundos. Repite decenas de veces y crece el tiempo muy despacio.", "Complementa con independencia en casa (que no te siga a todas partes), trabajo mental con juguetes rellenables y ejercicio antes de salir. Si destruye o se autolesiona, agenda una asesoría: los casos severos necesitan plan profesional."] },
  { slug: "por-que-ladra-mi-perro", title: "¿Por qué ladra mi perro? 5 causas y su solución", category: "Conducta", excerpt: "Alerta, demanda, aburrimiento, miedo o frustración: cada ladrido pide una respuesta distinta.", readMin: 6, image: IMG.training, content: ["Antes de corregir, identifica la causa. El ladrido de alerta busca avisarte; el de demanda busca atención; el de aburrimiento revela una rutina pobre; el de miedo pide distancia.", "Regla de oro: nunca refuerces el ladrido de demanda dándole lo que pide mientras ladra. Espera 3 segundos de silencio, marca y premia la calma.", "Revisa la rutina: un perro que pasea, juega, entrena 10 minutos y olfatea a diario ladra mucho menos. El ladrido es un síntoma, la rutina es la cura."] },
  { slug: "socializar-cachorro-bien", title: "Socializar bien a un cachorro (sin cometer el error más común)", category: "Cachorros", excerpt: "Socializar no es 'que juegue con todos los perros'. Es construir confianza con el mundo, a su ritmo.", readMin: 5, image: IMG.puppy, content: ["Entre las 3 y 16 semanas el cerebro del cachorro acepta lo nuevo como normal. Lo que no conoce en esa ventana, podría temerlo de adulto.", "El error más común es sobreexponerlo: parques de perros caóticos y saludos forzados crean más miedos de los que previenen.", "Hazlo bien: estímulos nuevos a distancia, siempre con premios, dejando que el cachorro decida acercarse. Calidad sobre cantidad: 5 experiencias positivas valen más que 50 abrumadoras."] },
  { slug: "miedo-polvora-fuegos", title: "Miedo a la pólvora: prepáralo desde ya", category: "Miedos", excerpt: "Diciembre no tiene que ser una pesadilla. Plan de desensibilización y manejo para noches de fiesta.", readMin: 6, image: IMG.advanced, content: ["La desensibilización se construye semanas antes: sonidos de pólvora grabados a volumen mínimo mientras come algo delicioso, subiendo el volumen apenas 5% cada día.", "Crea desde ya su refugio: el lugar más interno de la casa, su cama, una manta con tu olor y música constante que amortigüe el exterior.", "El día del evento: paseo y juego antes de las 5 pm, casa bien cerrada, cortinas abajo y compañía tranquila. Jamás lo castigues por temblar: el miedo no se corrige, se acompaña."] },
  { slug: "tira-de-la-correa-solucion", title: "Mi perro tira de la correa: la solución sin castigos", category: "Paseo", excerpt: "Tira porque funciona. Cambia la regla del juego y el paseo se transforma en dos semanas.", readMin: 5, image: IMG.walk, content: ["Los perros repiten lo que funciona: tirar los acerca al árbol, al perro o al parque. Si avanzar solo ocurre con la correa floja, el comportamiento cambia solo.", "Practica en tramos cortos: premia cada mirada y cada momento junto a tu pierna. Al inicio premia seguido, cada 3-5 pasos.", "Alterna caminata estructurada con minutos de 'libre' para oler: un paseo con olfateo libre cansa y relaja el doble que uno de solo caminar."] },
  { slug: "cachorro-muerde-todo", title: "Mi cachorro muerde manos y muebles: qué hacer (y qué no)", category: "Cachorros", excerpt: "Morder es normal en cachorros; enseñarle con qué sí y con qué no, es tu tarea de las primeras semanas.", readMin: 5, image: IMG.agility, content: ["Los cachorros exploran con la boca y además les duelen las encías al mudar dientes. Morder no es agresión: es desarrollo.", "Redirige siempre: cada vez que busque tu mano, ofrece un mordedor adecuado y celebra cuando lo elija. Ten juguetes en cada habitación.", "Si insiste con la piel, detén el juego 10-20 segundos con calma. Aprenderá que los dientes en la piel pausan la diversión, sin gritos ni castigos."] },
];

export const plans = [
  { id: "mensual", name: "Mensual", price: 29900, period: "/mes", desc: "Ideal para empezar un curso completo", features: ["Todos los cursos y lecciones", "Guías de comportamiento", "Seguimiento de progreso", "10% dto. en spa y peluquería"] },
  { id: "trimestral", name: "Trimestral", price: 74900, period: "/3 meses", desc: "El favorito de las familias EDUCAN", badge: "Más elegido", features: ["Todo lo del plan Mensual", "1 asesoría de comportamiento incluida", "15% dto. en tienda y concentrado", "Soporte prioritario WhatsApp"] },
  { id: "anual", name: "Anual", price: 239900, period: "/año", desc: "Acompañamiento completo todo el año", features: ["Todo lo del plan Trimestral", "2 sesiones presenciales al año", "20% dto. en spa, tienda y guardería", "Certificado EDUCAN de obediencia"] },
];

export const testimonials = [
  { name: "Carolina M.", dog: "Rocky · Pastor Alemán", text: "En 3 semanas Rocky dejó de tirar de la correa y ahora paseamos tranquilos por el barrio. Las lecciones de 10 minutos son perfectas con mi trabajo.", stars: 5 },
  { name: "Andrés y Luisa", dog: "Mía · Golden de 4 meses", text: "Empezamos en la prueba gratis por la mordida de cachorro y nos quedamos con el plan trimestral. La asesoría nos cambió la convivencia.", stars: 5 },
  { name: "Jorge P.", dog: "Toby · Criollo rescatado", text: "Toby tenía pánico a quedarse solo. Con el protocolo de ansiedad y el seguimiento por WhatsApp hoy se queda tranquilo toda la mañana.", stars: 5 },
  { name: "Diana R.", dog: "Luna · Shih Tzu", text: "El spa a domicilio es otra cosa: sin jaulas, sin estrés y me mandan fotos de todo. Luna sale feliz y oliendo delicioso.", stars: 5 },
];

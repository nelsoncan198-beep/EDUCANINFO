import { db } from "@/db";
import { courses, lessons, services, products, articles } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureSeeded } from "./seed";
import { seedCourses, seedServices, seedProducts, seedArticles } from "./data";

export type Lesson = { id: number; courseId: number; title: string; description: string; steps: string[]; durationMin: number; isPreview: boolean; sortOrder: number };
export type Course = { id: number; slug: string; title: string; description: string; level: string; category: string; durationLabel: string; image: string; lessons: Lesson[] };
export type Service = typeof services.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Article = typeof articles.$inferSelect;

function fallbackCourses(): Course[] {
  return seedCourses.map((c, i) => ({
    id: i + 1, slug: c.slug, title: c.title, description: c.description, level: c.level, category: c.category, durationLabel: c.durationLabel, image: c.image,
    lessons: c.lessons.map((l, j) => ({ id: (i + 1) * 100 + j, courseId: i + 1, title: l.title, description: l.description, steps: l.steps, durationMin: l.durationMin, isPreview: l.isPreview, sortOrder: j })),
  }));
}

export async function getCourses(): Promise<Course[]> {
  try {
    await ensureSeeded();
    const cs = await db.select().from(courses).orderBy(asc(courses.sortOrder));
    const ls = await db.select().from(lessons).orderBy(asc(lessons.sortOrder));
    return cs.map((c) => ({ ...c, lessons: ls.filter((l) => l.courseId === c.id) as Lesson[] }));
  } catch { return fallbackCourses(); }
}

export async function getCourse(slug: string): Promise<Course | null> {
  const all = await getCourses();
  return all.find((c) => c.slug === slug) ?? null;
}

export async function getServices(): Promise<Service[]> {
  try {
    await ensureSeeded();
    return await db.select().from(services).orderBy(asc(services.sortOrder));
  } catch {
    return seedServices.map((s, i) => ({ id: i + 1, sortOrder: i, ...s })) as Service[];
  }
}
export async function getProducts(): Promise<Product[]> {
  try {
    await ensureSeeded();
    return await db.select().from(products).orderBy(asc(products.sortOrder));
  } catch {
    return seedProducts.map((p, i) => ({ ...p, id: i + 1, sortOrder: i, oldPrice: p.oldPrice ?? null })) as unknown as Product[];
  }
}
export async function getArticles(): Promise<Article[]> {
  try {
    await ensureSeeded();
    return await db.select().from(articles).orderBy(asc(articles.sortOrder));
  } catch {
    return seedArticles.map((a, i) => ({ id: i + 1, sortOrder: i, ...a })) as Article[];
  }
}
export async function getArticle(slug: string): Promise<Article | null> {
  const all = await getArticles();
  return all.find((a) => a.slug === slug) ?? null;
}
export { eq };

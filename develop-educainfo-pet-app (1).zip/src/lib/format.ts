export const fmtCOP = (n: number) => "$" + n.toLocaleString("es-CO");
export const fmtDate = (d: Date | string) => new Date(d).toLocaleDateString("es-CO", { day: "numeric", month: "long", year: "numeric" });

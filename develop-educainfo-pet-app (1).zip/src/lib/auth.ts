import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

const SECRET = process.env.AUTH_SECRET || "educainfo-educan-secret-2026";
export const SESSION_COOKIE = "educainfo_session";

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}
export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(":");
    const calc = scryptSync(password, salt, 64);
    return timingSafeEqual(calc, Buffer.from(hash, "hex"));
  } catch { return false; }
}
function sign(payload: string) { return createHmac("sha256", SECRET).update(payload).digest("hex"); }

export async function setSession(userId: number) {
  const payload = Buffer.from(JSON.stringify({ uid: userId, t: Date.now() })).toString("base64url");
  const store = await cookies();
  store.set(SESSION_COOKIE, `${payload}.${sign(payload)}`, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 30 });
}
export async function clearSession() { const s = await cookies(); s.delete(SESSION_COOKIE); }

export type SafeUser = { id: number; name: string; email: string; phone: string; plan: string; trialStart: Date; trialEnd: Date; subscriptionEnd: Date | null; createdAt: Date };

export async function getCurrentUser(): Promise<SafeUser | null> {
  try {
    const store = await cookies();
    const raw = store.get(SESSION_COOKIE)?.value;
    if (!raw) return null;
    const [payload, sig] = raw.split(".");
    if (!payload || sign(payload) !== sig) return null;
    const { uid } = JSON.parse(Buffer.from(payload, "base64url").toString());
    const [u] = await db.select().from(users).where(eq(users.id, uid)).limit(1);
    if (!u) return null;
    return { id: u.id, name: u.name, email: u.email, phone: u.phone, plan: u.plan, trialStart: u.trialStart, trialEnd: u.trialEnd, subscriptionEnd: u.subscriptionEnd, createdAt: u.createdAt };
  } catch { return null; }
}

export type Access = { status: "trial" | "premium" | "expired" | "guest"; daysLeft: number; hasAccess: boolean; label: string };

export function getAccess(user: SafeUser | null): Access {
  if (!user) return { status: "guest", daysLeft: 0, hasAccess: false, label: "Sin cuenta" };
  const now = Date.now();
  if (user.subscriptionEnd && new Date(user.subscriptionEnd).getTime() > now) {
    const days = Math.ceil((new Date(user.subscriptionEnd).getTime() - now) / 86400000);
    return { status: "premium", daysLeft: days, hasAccess: true, label: `Premium · ${days} días` };
  }
  const trialEnd = new Date(user.trialEnd).getTime();
  if (trialEnd > now) {
    const days = Math.max(0, Math.ceil((trialEnd - now) / 86400000));
    return { status: "trial", daysLeft: days, hasAccess: true, label: `Prueba gratis · ${days} día${days === 1 ? "" : "s"} restante${days === 1 ? "" : "s"}` };
  }
  return { status: "expired", daysLeft: 0, hasAccess: false, label: "Prueba finalizada" };
}


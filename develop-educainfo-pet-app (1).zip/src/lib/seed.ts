import { db } from "@/db";
import { courses, lessons, services, products, articles, users } from "@/db/schema";
import { seedCourses, seedServices, seedProducts, seedArticles } from "./data";
import { hashPassword } from "./auth";
import { eq } from "drizzle-orm";

let seeded = false;

export async function ensureSeeded() {
  if (seeded) return;
  try {
    const existing = await db.select({ id: courses.id }).from(courses).limit(1);
    if (existing.length === 0) {
      for (let i = 0; i < seedCourses.length; i++) {
        const c = seedCourses[i];
        const [row] = await db.insert(courses).values({ slug: c.slug, title: c.title, description: c.description, level: c.level, category: c.category, durationLabel: c.durationLabel, image: c.image, sortOrder: i }).returning();
        for (let j = 0; j < c.lessons.length; j++) {
          const l = c.lessons[j];
          await db.insert(lessons).values({ courseId: row.id, title: l.title, description: l.description, steps: l.steps, durationMin: l.durationMin, isPreview: l.isPreview, sortOrder: j });
        }
      }
      for (let i = 0; i < seedServices.length; i++) { const s = seedServices[i]; await db.insert(services).values({ ...s, sortOrder: i }); }
      for (let i = 0; i < seedProducts.length; i++) { const p = seedProducts[i]; await db.insert(products).values({ ...p, oldPrice: p.oldPrice ?? null, sortOrder: i }); }
      for (let i = 0; i < seedArticles.length; i++) { const a = seedArticles[i]; await db.insert(articles).values({ ...a, sortOrder: i }); }
    }
    // Usuario demo con prueba activa
    const demoEmail = "demo@educainfo.co";
    const [demo] = await db.select().from(users).where(eq(users.email, demoEmail)).limit(1);
    if (!demo) {
      const now = new Date();
      await db.insert(users).values({
        name: "Familia Demo", email: demoEmail, phone: "3162826043",
        passwordHash: hashPassword("educan123"), plan: "trial",
        trialStart: now, trialEnd: new Date(now.getTime() + 7 * 86400000),
      });
    }
    seeded = true;
  } catch (e) {
    console.error("seed error", e);
  }
}

import Link from "next/link";
import { ChevronRight, HeartHandshake } from "lucide-react";
import { getArticles } from "@/lib/catalog";
import { getCurrentUser } from "@/lib/auth";
import { ConsultationForm } from "@/components/Forms";

export const dynamic = "force-dynamic";
const issues = [
  ["Ansiedad por separación", "No puede quedarse solo sin entrar en pánico"],
  ["Ladridos excesivos", "Alerta, demanda o aburrimiento: cada uno se trata distinto"],
  ["Miedos y fobias", "Pólvora, truenos, personas o ruidos de la calle"],
  ["Reactividad y agresión", "Explota con perros o personas en el paseo"],
  ["Destrucción y robo de comida", "Muebles, zapatos y la basura no sobreviven"],
  ["Higiene en casa", "Sigue haciendo sus necesidades adentro"],
];

export default async function Page() {
  const articles = await getArticles();
  const user = await getCurrentUser().catch(() => null);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="overflow-hidden rounded-[2rem] bg-brand-950 text-white">
        <div className="p-8 sm:p-12">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-extrabold tracking-widest ring-1 ring-white/20"><HeartHandshake className="h-4 w-4 text-accent-500" /> ASESORÍA DE COMPORTAMIENTO EDUCAN</span>
          <h1 className="font-display mt-4 max-w-2xl text-4xl font-semibold">Entender a tu perro es el primer paso para ayudarlo</h1>
          <p className="mt-3 max-w-2xl leading-relaxed text-brand-100">Detrás de cada “mal comportamiento” hay una emoción. Lee nuestras guías gratuitas o cuéntanos tu caso y un adiestrador profesional te acompaña con un plan hecho a tu medida.</p>
        </div>
      </div>

      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {issues.map(([t, d]) => (
          <div key={t} className="rounded-3xl border border-brand-100 bg-white p-5">
            <h3 className="font-display text-lg font-semibold text-brand-950">{t}</h3>
            <p className="mt-1 text-sm text-slate-600">{d}</p>
          </div>
        ))}
      </div>

      <div className="mt-14 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
        <div>
          <h2 className="font-display text-3xl font-semibold text-brand-950">Guías de comportamiento</h2>
          <p className="mt-2 text-slate-600">Escritas por el equipo EDUCAN, en lenguaje claro y con pasos aplicables hoy mismo.</p>
          <div className="mt-7 grid gap-6 sm:grid-cols-2">
            {articles.map((a) => (
              <Link key={a.id} href={`/comportamiento/${a.slug}`} className="group overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-brand-100 transition hover:shadow-xl">
                <img src={a.image} alt={a.title} className="h-44 w-full object-cover transition duration-500 group-hover:scale-105" />
                <div className="p-5">
                  <span className="rounded-full bg-accent-100 px-2.5 py-1 text-[11px] font-extrabold text-accent-600">{a.category}</span>
                  <h3 className="font-display mt-3 text-lg font-semibold leading-snug text-brand-950">{a.title}</h3>
                  <p className="mt-2 line-clamp-3 text-sm text-slate-600">{a.excerpt}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-extrabold text-brand-700">Leer guía · {a.readMin} min <ChevronRight className="h-4 w-4" /></span>
                </div>
              </Link>
            ))}
          </div>
        </div>
        <div className="lg:sticky lg:top-32 self-start">
          <ConsultationForm userName={user?.name || ""} userPhone={user?.phone || ""} />
          <div className="mt-5 rounded-3xl bg-white p-6 ring-1 ring-brand-100">
            <h3 className="font-display text-lg font-semibold text-brand-950">¿Prefieres atención presencial?</h3>
            <p className="mt-2 text-sm text-slate-600">La asesoría completa incluye evaluación de 60 minutos, plan escrito y seguimiento por WhatsApp durante 7 días.</p>
            <Link href="/spa" className="mt-4 block rounded-full bg-brand-900 py-3 text-center text-sm font-extrabold text-white hover:bg-brand-700">Reservar asesoría — $90.000</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

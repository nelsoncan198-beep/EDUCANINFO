import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Clock3, HeartHandshake } from "lucide-react";
import { getArticle, getArticles } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = await getArticle(slug);
  if (!article) notFound();
  const others = (await getArticles()).filter((a) => a.slug !== slug).slice(0, 3);
  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <Link href="/comportamiento" className="inline-flex items-center gap-1 text-sm font-extrabold text-brand-700"><ArrowLeft className="h-4 w-4" /> Todas las guías</Link>
      <img src={article.image} alt={article.title} className="mt-6 h-72 w-full rounded-[2rem] object-cover sm:h-96" />
      <div className="mt-6 flex gap-2">
        <span className="rounded-full bg-accent-500 px-3 py-1 text-xs font-extrabold text-brand-950">{article.category}</span>
        <span className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-extrabold text-slate-600 ring-1 ring-brand-100"><Clock3 className="h-3.5 w-3.5" />{article.readMin} min de lectura</span>
      </div>
      <h1 className="font-display mt-4 text-4xl font-semibold leading-tight text-brand-950">{article.title}</h1>
      <p className="mt-4 text-lg font-semibold leading-relaxed text-slate-600">{article.excerpt}</p>
      <div className="mt-8 space-y-5 rounded-[2rem] bg-white p-7 ring-1 ring-brand-100 sm:p-9">
        {(article.content as string[]).map((p, i) => <p key={i} className="leading-[1.85] text-slate-700">{p}</p>)}
      </div>
      <div className="mt-8 rounded-[2rem] bg-brand-950 p-7 text-white sm:p-9">
        <HeartHandshake className="h-10 w-10 text-accent-500" />
        <h2 className="font-display mt-3 text-2xl font-semibold">¿Tu caso necesita ayuda personalizada?</h2>
        <p className="mt-2 text-brand-100">Cada perro es un mundo. Agenda una asesoría de comportamiento con EDUCAN y recibe un plan hecho para tu familia, en sede o a domicilio.</p>
        <div className="mt-5 flex flex-wrap gap-3">
          <Link href="/comportamiento" className="rounded-full bg-accent-500 px-6 py-3.5 font-extrabold text-brand-950">Solicitar asesoría</Link>
          <Link href="/entrenamiento" className="rounded-full bg-white/10 px-6 py-3.5 font-extrabold ring-1 ring-white/25">Ver cursos relacionados</Link>
        </div>
      </div>
      <h2 className="font-display mt-12 text-2xl font-semibold text-brand-950">Sigue aprendiendo</h2>
      <div className="mt-5 grid gap-4 sm:grid-cols-3">
        {others.map((a) => (
          <Link key={a.id} href={`/comportamiento/${a.slug}`} className="overflow-hidden rounded-3xl bg-white ring-1 ring-brand-100 transition hover:shadow-lg">
            <img src={a.image} alt={a.title} className="h-32 w-full object-cover" />
            <div className="p-4"><span className="text-[11px] font-extrabold text-accent-600">{a.category}</span><h3 className="font-display mt-1 font-semibold leading-snug text-brand-950">{a.title}</h3></div>
          </Link>
        ))}
      </div>
    </div>
  );
}

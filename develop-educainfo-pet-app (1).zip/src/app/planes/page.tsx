import Link from "next/link";
import { BadgeCheck, CheckCircle2, Crown, MessageCircle, ShieldCheck, Timer } from "lucide-react";
import { plans, WHATSAPP } from "@/lib/data";
import { getCurrentUser, getAccess } from "@/lib/auth";
import { fmtCOP } from "@/lib/format";
import SubscribeButton from "@/components/SubscribeButton";

export const dynamic = "force-dynamic";

export default async function Page() {
  const user = await getCurrentUser().catch(() => null);
  const access = getAccess(user);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="text-center">
        <span className="inline-flex items-center gap-2 rounded-full bg-accent-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-accent-600"><Crown className="h-4 w-4" /> PLANES EDUCAINFO PREMIUM</span>
        <h1 className="font-display mx-auto mt-4 max-w-2xl text-4xl font-semibold text-brand-950 sm:text-5xl">Primero pruébalo 7 días gratis. Después, elige tu plan.</h1>
        <p className="mx-auto mt-4 max-w-2xl text-slate-600">Todos los planes incluyen acceso total e ilimitado a cursos de adiestramiento y guías de comportamiento, seguimiento de progreso y descuentos en servicios EDUCAN.</p>
        {user && (
          <p className={`mt-5 inline-flex items-center gap-2 rounded-full px-5 py-2.5 font-extrabold ${access.status === "premium" ? "bg-accent-100 text-accent-600" : access.status === "trial" ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`}>
            {access.status === "premium" ? <BadgeCheck className="h-5 w-5" /> : <Timer className="h-5 w-5" />} Tu estado actual: {access.label}
          </p>
        )}
      </div>

      <div className="mx-auto mt-8 flex max-w-3xl items-center gap-4 rounded-3xl bg-brand-950 p-6 text-white">
        <Timer className="h-10 w-10 shrink-0 text-accent-500" />
        <p className="font-semibold leading-relaxed"><b className="text-accent-500">¿Cómo funciona?</b> Te registras gratis → entrenas 7 días sin límites y sin tarjeta → al día 8 eliges un plan para continuar. Las lecciones de vista previa quedan abiertas siempre.</p>
      </div>

      <div className="mt-12 grid gap-6 md:grid-cols-3">
        {plans.map((p) => (
          <article key={p.id} className={`relative flex flex-col rounded-[2rem] border-2 p-7 ${p.badge ? "border-accent-500 bg-white shadow-2xl" : "border-brand-100 bg-white"}`}>
            {p.badge && <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-accent-500 px-4 py-1 text-xs font-black text-brand-950">{p.badge.toUpperCase()}</span>}
            <h2 className="font-display text-2xl font-semibold text-brand-950">{p.name}</h2>
            <p className="mt-1 text-sm text-slate-500">{p.desc}</p>
            <p className="mt-5"><span className="font-display text-5xl font-semibold text-brand-900">{fmtCOP(p.price)}</span><span className="font-bold text-slate-500"> {p.period}</span></p>
            <p className="text-xs font-bold text-emerald-600">Primeros 7 días: $0 con tu registro</p>
            <ul className="mt-6 flex-1 space-y-3">{p.features.map((f) => <li key={f} className="flex gap-2 text-sm font-semibold text-slate-700"><CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" />{f}</li>)}</ul>
            <div className="mt-7"><SubscribeButton planId={p.id} planName={p.name} highlight={!!p.badge} isLogged={!!user} /></div>
          </article>
        ))}
      </div>

      <div className="mt-12 grid gap-5 md:grid-cols-3">
        {[["Sin tarjeta para probar", "La prueba de 7 días no pide ningún medio de pago.", ShieldCheck], ["Cancela cuando quieras", "Sin permanencias ni letras pequeñas. Tu progreso se conserva.", BadgeCheck], ["Paga como prefieras", "Al activar tu plan coordinamos el pago por WhatsApp: transferencia, Nequi o en sede.", MessageCircle]].map(([t, d, Icon]) => {
          const I = Icon as typeof ShieldCheck;
          return (<div key={t as string} className="rounded-3xl bg-white p-6 ring-1 ring-brand-100"><I className="h-8 w-8 text-brand-600" /><h3 className="font-display mt-3 text-lg font-semibold text-brand-950">{t as string}</h3><p className="mt-1 text-sm text-slate-600">{d as string}</p></div>);
        })}
      </div>

      <div className="mt-12 rounded-[2rem] bg-accent-500 p-8 text-center text-brand-950 sm:p-10">
        <h2 className="font-display text-3xl font-semibold">¿Dudas sobre qué plan te conviene?</h2>
        <p className="mx-auto mt-2 max-w-xl font-semibold text-brand-900/80">Cuéntanos la edad y el caso de tu perro y te recomendamos el camino ideal, sin compromiso.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <a href={`https://wa.me/${WHATSAPP}?text=Hola%20EDUCAN,%20quiero%20asesor%C3%ADa%20sobre%20los%20planes%20de%20EducaInfo`} target="_blank" className="inline-flex items-center gap-2 rounded-full bg-brand-950 px-7 py-4 font-extrabold text-white"><MessageCircle className="h-5 w-5" /> Preguntar por WhatsApp</a>
          {!user && <Link href="/registro" className="rounded-full bg-white px-7 py-4 font-extrabold text-brand-950">Empezar mi prueba gratis</Link>}
        </div>
      </div>
    </div>
  );
}

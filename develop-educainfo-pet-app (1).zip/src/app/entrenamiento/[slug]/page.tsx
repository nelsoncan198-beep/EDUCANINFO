import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Clock3, Crown, Layers, TrendingUp } from "lucide-react";
import { getCourse, getCourses } from "@/lib/catalog";
import { getCurrentUser, getAccess } from "@/lib/auth";
import { db } from "@/db";
import { progress } from "@/db/schema";
import { eq } from "drizzle-orm";
import LessonList from "@/components/LessonList";
import { CourseCard } from "@/components/Cards";

export const dynamic = "force-dynamic";

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const course = await getCourse(slug);
  if (!course) notFound();
  const user = await getCurrentUser().catch(() => null);
  const access = getAccess(user);
  let completedIds: number[] = [];
  if (user) { try { const rows = await db.select().from(progress).where(eq(progress.userId, user.id)); completedIds = rows.map((r) => r.lessonId); } catch {} }
  const doneCount = course.lessons.filter((l) => completedIds.includes(l.id)).length;
  const pct = course.lessons.length ? Math.round((doneCount / course.lessons.length) * 100) : 0;
  const others = (await getCourses()).filter((c) => c.slug !== slug).slice(0, 3);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <Link href="/entrenamiento" className="inline-flex items-center gap-1 text-sm font-extrabold text-brand-700 hover:text-brand-900"><ArrowLeft className="h-4 w-4" /> Todos los cursos</Link>
      <div className="mt-6 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
        <div>
          <div className="overflow-hidden rounded-[2rem]">
            <img src={course.image} alt={course.title} className="h-64 w-full object-cover sm:h-80" />
          </div>
          <div className="mt-6 flex flex-wrap gap-2">
            <span className="rounded-full bg-brand-900 px-3 py-1 text-xs font-extrabold text-white">{course.category}</span>
            <span className="rounded-full bg-accent-500 px-3 py-1 text-xs font-extrabold text-brand-950">{course.level}</span>
            <span className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-extrabold text-slate-600 ring-1 ring-brand-100"><Clock3 className="h-3.5 w-3.5" />{course.durationLabel}</span>
            <span className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-extrabold text-slate-600 ring-1 ring-brand-100"><Layers className="h-3.5 w-3.5" />{course.lessons.length} lecciones</span>
          </div>
          <h1 className="font-display mt-4 text-4xl font-semibold text-brand-950">{course.title}</h1>
          <p className="mt-3 max-w-2xl leading-relaxed text-slate-600">{course.description}</p>
          {user && (
            <div className="mt-6 rounded-3xl bg-white p-5 ring-1 ring-brand-100">
              <p className="flex items-center justify-between text-sm font-extrabold text-brand-950"><span className="flex items-center gap-2"><TrendingUp className="h-5 w-5 text-emerald-500" /> Tu progreso en este curso</span><span>{doneCount}/{course.lessons.length} · {pct}%</span></p>
              <div className="mt-3 h-3 overflow-hidden rounded-full bg-brand-50"><div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${pct}%` }} /></div>
            </div>
          )}
          <h2 className="font-display mt-10 text-2xl font-semibold text-brand-950">Lecciones del curso</h2>
          <div className="mt-4"><LessonList lessons={course.lessons} completedIds={completedIds} hasAccess={access.hasAccess} isLogged={!!user} /></div>
        </div>
        <aside className="space-y-5">
          <div className="rounded-3xl bg-brand-950 p-6 text-white">
            <Crown className="h-9 w-9 text-accent-500" />
            <h3 className="font-display mt-3 text-2xl font-semibold">{access.status === "guest" ? "Desbloquéalo todo por 7 días gratis" : access.hasAccess ? access.label : "Tu acceso completo terminó"}</h3>
            <p className="mt-2 text-sm leading-relaxed text-brand-100">{access.status === "guest" ? "Crea tu cuenta en 1 minuto y empieza este curso completo hoy. Sin tarjeta." : access.hasAccess ? "Disfruta todas las lecciones y marca tu progreso. ¡Constancia de 10 minutos al día!" : "Reactiva con Premium y sigue justo donde ibas, con tu progreso guardado."}</p>
            <Link href={access.hasAccess ? "/mi-cuenta" : access.status === "guest" ? "/registro" : "/planes"} className="mt-5 block rounded-full bg-accent-500 py-3.5 text-center font-extrabold text-brand-950 hover:bg-accent-600">{access.hasAccess ? "Ir a mi cuenta" : access.status === "guest" ? "Crear cuenta gratis" : "Activar Premium"}</Link>
          </div>
          <div className="rounded-3xl bg-white p-6 ring-1 ring-brand-100">
            <h3 className="font-display text-lg font-semibold text-brand-950">¿Necesitas ayuda con este tema?</h3>
            <p className="mt-2 text-sm text-slate-600">Agenda una sesión presencial o asesoría de comportamiento con adiestradores EDUCAN en San Felipe o a domicilio.</p>
            <Link href="/spa" className="mt-4 block rounded-full bg-brand-900 py-3 text-center text-sm font-extrabold text-white hover:bg-brand-700">Reservar sesión presencial</Link>
            <Link href="/comportamiento" className="mt-2 block rounded-full bg-brand-50 py-3 text-center text-sm font-extrabold text-brand-800">Asesoría de comportamiento</Link>
          </div>
        </aside>
      </div>
      <h2 className="font-display mt-16 text-2xl font-semibold text-brand-950">Sigue aprendiendo</h2>
      <div className="mt-6 grid gap-6 md:grid-cols-3">{others.map((c) => <CourseCard key={c.id} course={c} />)}</div>
    </div>
  );
}

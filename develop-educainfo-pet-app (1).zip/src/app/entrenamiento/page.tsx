import Link from "next/link";
import { Clock3, Crown, GraduationCap } from "lucide-react";
import { getCourses } from "@/lib/catalog";
import { getCurrentUser, getAccess } from "@/lib/auth";
import { CoursesExplorer } from "@/components/Explorers";

export const dynamic = "force-dynamic";

export default async function Page() {
  const courses = await getCourses();
  const user = await getCurrentUser().catch(() => null);
  const access = getAccess(user);
  const totalLessons = courses.reduce((s, c) => s + c.lessons.length, 0);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="overflow-hidden rounded-[2rem] bg-brand-950 text-white">
        <div className="grid items-center gap-6 p-8 sm:p-12 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-extrabold tracking-widest ring-1 ring-white/20"><GraduationCap className="h-4 w-4 text-accent-500" /> ESCUELA ONLINE EDUCAN</span>
            <h1 className="font-display mt-4 text-4xl font-semibold">Adiestramiento canino paso a paso</h1>
            <p className="mt-3 max-w-xl leading-relaxed text-brand-100">{courses.length} cursos · {totalLessons} lecciones cortas con tareas diarias. La primera lección de cada curso es abierta; con tu cuenta tienes <b className="text-white">7 días de acceso total gratis</b>.</p>
          </div>
          <div className="rounded-3xl bg-white/10 p-6 ring-1 ring-white/15">
            {access.status === "guest" ? (<>
              <p className="flex items-center gap-2 font-display text-xl font-semibold"><Clock3 className="h-6 w-6 text-accent-500" /> Tu prueba de 7 días te espera</p>
              <p className="mt-2 text-sm text-brand-100">Regístrate gratis y desbloquea todos los cursos hoy mismo.</p>
              <Link href="/registro" className="mt-4 block rounded-full bg-accent-500 py-3.5 text-center font-extrabold text-brand-950 hover:bg-accent-600">Activar mis 7 días gratis</Link>
              <Link href="/ingresar" className="mt-2 block rounded-full bg-white/10 py-3 text-center text-sm font-extrabold ring-1 ring-white/25">Ya tengo cuenta</Link>
            </>) : access.hasAccess ? (<>
              <p className="flex items-center gap-2 font-display text-xl font-semibold"><Clock3 className="h-6 w-6 text-emerald-400" /> {access.label}</p>
              <p className="mt-2 text-sm text-brand-100">Tienes acceso completo a todas las lecciones. ¡A entrenar!</p>
              <Link href="/mi-cuenta" className="mt-4 block rounded-full bg-white py-3.5 text-center font-extrabold text-brand-900">Ver mi progreso</Link>
            </>) : (<>
              <p className="flex items-center gap-2 font-display text-xl font-semibold"><Crown className="h-6 w-6 text-accent-500" /> Tu prueba terminó</p>
              <p className="mt-2 text-sm text-brand-100">Sigue entrenando sin interrupción con Premium desde $29.900/mes.</p>
              <Link href="/planes" className="mt-4 block rounded-full bg-accent-500 py-3.5 text-center font-extrabold text-brand-950">Ver planes Premium</Link>
            </>)}
          </div>
        </div>
      </div>
      <div className="mt-10"><CoursesExplorer courses={courses} /></div>
    </div>
  );
}

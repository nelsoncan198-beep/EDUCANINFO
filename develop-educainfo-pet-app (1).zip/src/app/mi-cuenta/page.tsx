import Link from "next/link";
import { redirect } from "next/navigation";
import { CalendarCheck2, Clock3, Crown, Dog as DogIcon, GraduationCap, HeartHandshake, ShoppingBag, TrendingUp } from "lucide-react";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { dogs, bookings, orders, progress, consultations } from "@/db/schema";
import { getCurrentUser, getAccess } from "@/lib/auth";
import { fmtCOP, fmtDate } from "@/lib/format";
import { getCourses } from "@/lib/catalog";
import DogManager, { LogoutButton } from "@/components/DogManager";
import { CourseCard } from "@/components/Cards";

export const dynamic = "force-dynamic";

export default async function Page({ searchParams }: { searchParams: Promise<{ bienvenida?: string }> }) {
  const user = await getCurrentUser().catch(() => null);
  if (!user) redirect("/ingresar?next=/mi-cuenta");
  const sp = await searchParams;
  const access = getAccess(user);
  const [myDogs, myBookings, myOrders, myProgress, myConsults, courses] = await Promise.all([
    db.select().from(dogs).where(eq(dogs.userId, user.id)).catch(() => []),
    db.select().from(bookings).where(eq(bookings.userId, user.id)).orderBy(desc(bookings.createdAt)).catch(() => []),
    db.select().from(orders).where(eq(orders.userId, user.id)).orderBy(desc(orders.createdAt)).catch(() => []),
    db.select().from(progress).where(eq(progress.userId, user.id)).catch(() => []),
    db.select().from(consultations).where(eq(consultations.userId, user.id)).orderBy(desc(consultations.createdAt)).catch(() => []),
    getCourses(),
  ]);
  const totalLessons = courses.reduce((s, c) => s + c.lessons.length, 0);
  const pct = totalLessons ? Math.round((myProgress.length / totalLessons) * 100) : 0;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      {sp.bienvenida && (
        <div className="mb-6 rounded-3xl bg-emerald-500 px-6 py-5 text-white">
          <p className="font-display text-2xl font-semibold">¡Bienvenido a EducaInfo, {user.name.split(" ")[0]}!</p>
          <p className="mt-1 font-semibold text-emerald-50">Tu prueba gratuita de 7 días ya está activa hasta el {fmtDate(user.trialEnd)}. Elige un curso y entrena 10 minutos hoy.</p>
        </div>
      )}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-semibold text-brand-950">Hola, {user.name.split(" ")[0]}</h1>
          <p className="mt-1 font-semibold text-slate-500">{user.email} · Cliente EducaInfo desde {fmtDate(user.createdAt)}</p>
        </div>
        <LogoutButton />
      </div>

      <div className="mt-7 grid gap-5 lg:grid-cols-3">
        <div className={`rounded-3xl p-6 text-white ${access.status === "premium" ? "bg-accent-500 text-brand-950" : access.status === "trial" ? "bg-brand-950" : "bg-rose-600"}`}>
          {access.status === "premium" ? <Crown className="h-9 w-9" /> : <Clock3 className="h-9 w-9 text-accent-500" />}
          <p className="mt-3 text-xs font-extrabold uppercase tracking-widest opacity-80">Tu acceso a adiestramiento</p>
          <p className="font-display mt-1 text-3xl font-semibold">{access.status === "premium" ? "Premium activo" : access.status === "trial" ? `Prueba: ${access.daysLeft} día${access.daysLeft === 1 ? "" : "s"} más` : "Prueba finalizada"}</p>
          <p className={`mt-1 text-sm font-semibold ${access.status === "premium" ? "text-brand-900/80" : "text-brand-100"}`}>{access.status === "trial" ? `Disfruta hasta el ${fmtDate(user.trialEnd)}` : access.status === "premium" && user.subscriptionEnd ? `Vigente hasta el ${fmtDate(user.subscriptionEnd)}` : "Reactiva tu acceso para seguir aprendiendo"}</p>
          {access.status !== "premium" && <Link href="/planes" className="mt-4 inline-block rounded-full bg-accent-500 px-5 py-3 text-sm font-extrabold text-brand-950 hover:bg-accent-600">{access.status === "trial" ? "Asegurar mi Premium" : "Activar Premium ahora"}</Link>}
        </div>
        <div className="rounded-3xl bg-white p-6 ring-1 ring-brand-100">
          <TrendingUp className="h-9 w-9 text-emerald-500" />
          <p className="mt-3 text-xs font-extrabold uppercase tracking-widest text-slate-400">Progreso de aprendizaje</p>
          <p className="font-display mt-1 text-3xl font-semibold text-brand-950">{myProgress.length} de {totalLessons} lecciones</p>
          <div className="mt-3 h-3 overflow-hidden rounded-full bg-brand-50"><div className="h-full bg-emerald-500" style={{ width: `${pct}%` }} /></div>
          <p className="mt-2 text-sm font-bold text-slate-500">{pct}% de la escuela completado</p>
          <Link href="/entrenamiento" className="mt-3 inline-flex items-center gap-1 text-sm font-extrabold text-brand-700"><GraduationCap className="h-4 w-4" /> Seguir entrenando</Link>
        </div>
        <div className="rounded-3xl bg-white p-6 ring-1 ring-brand-100">
          <DogIcon className="h-9 w-9 text-brand-600" />
          <p className="mt-3 text-xs font-extrabold uppercase tracking-widest text-slate-400">Mi manada</p>
          <p className="font-display mt-1 text-3xl font-semibold text-brand-950">{myDogs.length} perro{myDogs.length === 1 ? "" : "s"}</p>
          <p className="mt-2 text-sm font-bold text-slate-500">{myDogs.map((d) => d.name).join(", ") || "Agrega a tu perro abajo"}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Link href="/spa" className="rounded-full bg-brand-50 px-4 py-2 text-sm font-extrabold text-brand-800">Reservar spa</Link>
            <Link href="/tienda" className="rounded-full bg-brand-50 px-4 py-2 text-sm font-extrabold text-brand-800">Comprar concentrado</Link>
          </div>
        </div>
      </div>

      <div className="mt-12 grid gap-10 lg:grid-cols-2">
        <section>
          <h2 className="font-display flex items-center gap-2 text-2xl font-semibold text-brand-950"><DogIcon className="h-6 w-6 text-brand-600" /> Mis perros</h2>
          <div className="mt-5"><DogManager initialDogs={myDogs} /></div>
        </section>
        <section className="space-y-8">
          <div>
            <h2 className="font-display flex items-center gap-2 text-2xl font-semibold text-brand-950"><CalendarCheck2 className="h-6 w-6 text-brand-600" /> Mis reservas</h2>
            {myBookings.length === 0 ? <p className="mt-4 rounded-2xl bg-white px-5 py-4 text-sm font-bold text-slate-500 ring-1 ring-brand-100">Sin reservas aún. <Link href="/spa" className="text-brand-700">Reserva un baño spa o una sesión →</Link></p> : (
              <div className="mt-4 space-y-3">{myBookings.map((b) => (
                <article key={b.id} className="flex flex-wrap items-center justify-between gap-3 rounded-3xl bg-white p-5 ring-1 ring-brand-100">
                  <div><p className="font-display font-semibold text-brand-950">{b.serviceName}</p><p className="text-sm font-semibold text-slate-500">Para {b.dogName} · {b.date} a las {b.time} · {b.mode === "domicilio" ? "A domicilio" : "En sede"}</p></div>
                  <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-extrabold text-amber-700">{b.status}</span>
                </article>))}</div>
            )}
          </div>
          <div>
            <h2 className="font-display flex items-center gap-2 text-2xl font-semibold text-brand-950"><ShoppingBag className="h-6 w-6 text-brand-600" /> Mis pedidos</h2>
            {myOrders.length === 0 ? <p className="mt-4 rounded-2xl bg-white px-5 py-4 text-sm font-bold text-slate-500 ring-1 ring-brand-100">Sin pedidos aún. <Link href="/tienda" className="text-brand-700">Ver la tienda →</Link></p> : (
              <div className="mt-4 space-y-3">{myOrders.map((o) => (
                <article key={o.id} className="rounded-3xl bg-white p-5 ring-1 ring-brand-100">
                  <div className="flex items-center justify-between"><p className="font-display font-semibold text-brand-950">Pedido #{o.id}</p><span className="rounded-full bg-brand-50 px-3 py-1 text-xs font-extrabold text-brand-700">{o.status}</span></div>
                  <p className="mt-1 text-sm font-semibold text-slate-500">{(o.items as { name: string; qty: number }[]).map((i) => `${i.qty} x ${i.name}`).join(", ")}</p>
                  <p className="mt-1 font-black text-brand-900">{fmtCOP(o.total)} · {fmtDate(o.createdAt)}</p>
                </article>))}</div>
            )}
          </div>
          {myConsults.length > 0 && (
            <div>
              <h2 className="font-display flex items-center gap-2 text-2xl font-semibold text-brand-950"><HeartHandshake className="h-6 w-6 text-brand-600" /> Mis asesorías</h2>
              <div className="mt-4 space-y-3">{myConsults.map((c) => (
                <article key={c.id} className="rounded-3xl bg-white p-5 ring-1 ring-brand-100">
                  <div className="flex items-center justify-between"><p className="font-display font-semibold text-brand-950">Caso de {c.dogName}</p><span className="rounded-full bg-accent-100 px-3 py-1 text-xs font-extrabold text-accent-600">{c.status}</span></div>
                  <p className="mt-1 text-sm font-semibold text-slate-500">{c.issue}</p>
                </article>))}</div>
            </div>
          )}
        </section>
      </div>

      <h2 className="font-display mt-14 text-2xl font-semibold text-brand-950">Continúa tu aprendizaje</h2>
      <div className="mt-6 grid gap-6 md:grid-cols-3">{courses.slice(0, 3).map((c) => <CourseCard key={c.id} course={c} />)}</div>
    </div>
  );
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const b = await req.json();
    if (!b.customerName || !b.phone || !Array.isArray(b.items) || b.items.length === 0) return NextResponse.json({ error: "Tu carrito está vacío o faltan tus datos." }, { status: 400 });
    const total = b.items.reduce((s: number, i: { price: number; qty: number }) => s + i.price * i.qty, 0);
    const user = await getCurrentUser();
    const [row] = await db.insert(orders).values({ userId: user?.id ?? null, customerName: b.customerName, phone: b.phone, address: b.address || "", items: b.items, total }).returning();
    const lines = b.items.map((i: { name: string; qty: number; price: number }) => `• ${i.qty} x ${i.name} — $${(i.price * i.qty).toLocaleString("es-CO")}`).join("\n");
    return NextResponse.json({ ok: true, order: row, whatsapp: `Hola EDUCAN, soy ${b.customerName}. Hice el pedido #${row.id} en EducaInfo:\n${lines}\nTotal: $${total.toLocaleString("es-CO")}\nDirección: ${b.address || "Recoger en sede"}` });
  } catch { return NextResponse.json({ error: "No pudimos registrar tu pedido." }, { status: 500 }); }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const b = await req.json();
    if (!b.customerName || !b.phone || !b.dogName || !b.serviceName || !b.date || !b.time) return NextResponse.json({ error: "Completa todos los campos de la reserva." }, { status: 400 });
    const user = await getCurrentUser();
    const [row] = await db.insert(bookings).values({
      userId: user?.id ?? null, customerName: b.customerName, phone: b.phone, dogName: b.dogName,
      serviceName: b.serviceName, date: b.date, time: b.time, mode: b.mode || "sede", notes: b.notes || "",
    }).returning();
    return NextResponse.json({ ok: true, booking: row, whatsapp: `Hola EDUCAN, soy ${b.customerName}. Reservé ${b.serviceName} para ${b.dogName} el ${b.date} a las ${b.time} (${b.mode === "domicilio" ? "a domicilio" : "en sede"}). Reserva #${row.id}` });
  } catch { return NextResponse.json({ error: "No pudimos guardar la reserva." }, { status: 500 }); }
}

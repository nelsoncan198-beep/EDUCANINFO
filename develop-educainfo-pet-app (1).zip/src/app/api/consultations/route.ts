import { NextResponse } from "next/server";
import { db } from "@/db";
import { consultations } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const b = await req.json();
    if (!b.name || !b.phone || !b.issue) return NextResponse.json({ error: "Cuéntanos tu nombre, teléfono y el caso de tu perro." }, { status: 400 });
    const user = await getCurrentUser();
    const [row] = await db.insert(consultations).values({ userId: user?.id ?? null, name: b.name, phone: b.phone, dogName: b.dogName || "Mi perro", issue: b.issue }).returning();
    return NextResponse.json({ ok: true, id: row.id });
  } catch { return NextResponse.json({ error: "No pudimos registrar tu solicitud." }, { status: 500 }); }
}

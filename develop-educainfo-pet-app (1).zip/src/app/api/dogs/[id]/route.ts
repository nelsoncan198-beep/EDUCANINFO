import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { dogs } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Ingresa a tu cuenta." }, { status: 401 });
  const { id } = await params;
  await db.delete(dogs).where(and(eq(dogs.id, Number(id)), eq(dogs.userId, user.id)));
  return NextResponse.json({ ok: true });
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { dogs } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Ingresa a tu cuenta." }, { status: 401 });
  const b = await req.json();
  if (!b.name) return NextResponse.json({ error: "El nombre de tu perro es obligatorio." }, { status: 400 });
  const [row] = await db.insert(dogs).values({ userId: user.id, name: b.name, breed: b.breed || "", ageLabel: b.ageLabel || "", size: b.size || "Mediano", behaviorNotes: b.behaviorNotes || "" }).returning();
  return NextResponse.json({ ok: true, dog: row });
}

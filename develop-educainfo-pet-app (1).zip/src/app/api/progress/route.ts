import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { progress } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Ingresa a tu cuenta para guardar tu progreso." }, { status: 401 });
  const { lessonId, completed } = await req.json();
  if (completed) {
    await db.insert(progress).values({ userId: user.id, lessonId: Number(lessonId) }).onConflictDoNothing();
  } else {
    await db.delete(progress).where(and(eq(progress.userId, user.id), eq(progress.lessonId, Number(lessonId))));
  }
  return NextResponse.json({ ok: true });
}

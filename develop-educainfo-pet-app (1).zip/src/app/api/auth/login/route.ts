import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { verifyPassword, setSession } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const { email, password } = await req.json();
    const [u] = await db.select().from(users).where(eq(users.email, String(email || "").toLowerCase().trim())).limit(1);
    if (!u || !verifyPassword(String(password || ""), u.passwordHash)) return NextResponse.json({ error: "Correo o contraseña incorrectos." }, { status: 401 });
    await setSession(u.id);
    return NextResponse.json({ ok: true, user: { name: u.name, email: u.email } });
  } catch { return NextResponse.json({ error: "Error al ingresar." }, { status: 500 }); }
}

import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword, setSession } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const { name, email, phone, password, dogName, dogBreed } = await req.json();
    if (!name || !email || !password || password.length < 6) return NextResponse.json({ error: "Completa nombre, correo y una contraseña de mínimo 6 caracteres." }, { status: 400 });
    const cleanEmail = String(email).toLowerCase().trim();
    const [exists] = await db.select().from(users).where(eq(users.email, cleanEmail)).limit(1);
    if (exists) return NextResponse.json({ error: "Ya existe una cuenta con ese correo. Ingresa a tu cuenta." }, { status: 409 });
    const now = new Date();
    const [u] = await db.insert(users).values({
      name: String(name).trim(), email: cleanEmail, phone: String(phone || ""), passwordHash: hashPassword(password),
      plan: "trial", trialStart: now, trialEnd: new Date(now.getTime() + 7 * 86400000),
    }).returning();
    if (dogName) {
      const { dogs } = await import("@/db/schema");
      await db.insert(dogs).values({ userId: u.id, name: String(dogName), breed: String(dogBreed || "") });
    }
    await setSession(u.id);
    return NextResponse.json({ ok: true, user: { name: u.name, email: u.email }, trialEnd: u.trialEnd });
  } catch { return NextResponse.json({ error: "No pudimos crear tu cuenta. Intenta de nuevo." }, { status: 500 }); }
}

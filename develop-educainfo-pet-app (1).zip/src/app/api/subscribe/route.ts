import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, subscriptions } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { plans } from "@/lib/data";

const months: Record<string, number> = { mensual: 1, trimestral: 3, anual: 12 };

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Ingresa a tu cuenta para activar tu plan." }, { status: 401 });
  const { planId } = await req.json();
  const plan = plans.find((p) => p.id === planId);
  if (!plan) return NextResponse.json({ error: "Plan no válido." }, { status: 400 });
  const base = user.subscriptionEnd && new Date(user.subscriptionEnd) > new Date() ? new Date(user.subscriptionEnd) : new Date();
  const ends = new Date(base); ends.setMonth(ends.getMonth() + (months[planId] || 1));
  await db.insert(subscriptions).values({ userId: user.id, plan: plan.name, amount: plan.price, endsAt: ends });
  await db.update(users).set({ plan: "premium", subscriptionEnd: ends }).where(eq(users.id, user.id));
  return NextResponse.json({ ok: true, endsAt: ends, plan: plan.name });
}

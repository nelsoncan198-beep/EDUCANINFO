import { Suspense } from "react";
import { LoginForm } from "@/components/AuthForms";
import { IMG } from "@/lib/data";
export default function Page() {
  return (
    <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-12 lg:grid-cols-2">
      <div className="hidden lg:block">
        <img src={IMG.training} alt="Perro entrenando con EDUCAN" className="h-[540px] w-full rounded-[2rem] object-cover" />
      </div>
      <Suspense><LoginForm /></Suspense>
    </div>
  );
}

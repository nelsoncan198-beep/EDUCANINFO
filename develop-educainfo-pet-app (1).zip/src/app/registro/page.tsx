import { Suspense } from "react";
import { RegisterForm } from "@/components/AuthForms";
import { IMG } from "@/lib/data";
import { CheckCircle2 } from "lucide-react";
export default function Page() {
  return (
    <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-12 lg:grid-cols-2">
      <div className="hidden lg:block relative">
        <img src={IMG.puppy} alt="Cachorro feliz" className="h-[600px] w-full rounded-[2rem] object-cover" />
        <div className="absolute bottom-5 left-5 right-5 rounded-3xl bg-brand-950/90 p-6 text-white backdrop-blur">
          <p className="font-display text-2xl font-semibold">Tu prueba incluye:</p>
          <ul className="mt-3 space-y-2">
            {["Todos los cursos de adiestramiento", "Guías de comportamiento completas", "Seguimiento de progreso por perro", "Descuentos al activar tu plan"].map((t) => <li key={t} className="flex gap-2 font-semibold"><CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />{t}</li>)}
          </ul>
        </div>
      </div>
      <Suspense><RegisterForm /></Suspense>
    </div>
  );
}

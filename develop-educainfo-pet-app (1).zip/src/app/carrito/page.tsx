import CartCheckout from "@/components/CartCheckout";
import { getCurrentUser } from "@/lib/auth";
export const dynamic = "force-dynamic";
export default async function Page() {
  const user = await getCurrentUser().catch(() => null);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="font-display text-4xl font-semibold text-brand-950">Tu carrito</h1>
      <p className="mt-2 text-slate-600">Revisa tu pedido de la tienda EDUCAN y confírmalo en un paso.</p>
      <div className="mt-8"><CartCheckout userName={user?.name || ""} userPhone={user?.phone || ""} /></div>
    </div>
  );
}

import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { CartProvider } from "@/components/CartProvider";
import { getCurrentUser, getAccess } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "EducaInfo | EDUCAN — Adiestramiento, Spa, Peluquería y Tienda Canina",
  description: "App de EDUCAN: cursos de adiestramiento canino con 7 días gratis, asesoría de comportamiento, spa y peluquería profesional, accesorios y concentrado a domicilio.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  let userName: string | null = null; let accessLabel = ""; let accessStatus = "guest";
  try { const u = await getCurrentUser(); if (u) { userName = u.name; const a = getAccess(u); accessLabel = a.label; accessStatus = a.status; } } catch {}
  return (
    <html lang="es">
      <body className="bg-cream text-slate-900 antialiased">
        <CartProvider>
          <Header userName={userName} accessLabel={accessLabel} accessStatus={accessStatus} />
          <main>{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}

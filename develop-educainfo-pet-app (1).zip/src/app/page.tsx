import Link from "next/link";
import { ArrowRight, BadgeCheck, BookOpenCheck, CalendarCheck2, CheckCircle2, GraduationCap, HeartHandshake, MapPin, MessageCircle, Phone, Scissors, ShieldCheck, ShoppingBag, Sparkles, Star, Timer, Truck, Crown, ChevronRight, Dog, ClipboardList, Wallet } from "lucide-react";
import { getCourses, getProducts, getServices, getArticles } from "@/lib/catalog";
import { CourseCard } from "@/components/Cards";
import ProductCard from "@/components/ProductCard";
import { ADDRESS, IMG, PHONES, WHATSAPP, plans, testimonials } from "@/lib/data";
import { fmtCOP as fmtCOP_PLACEHOLDER } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [courses, products, services, articles] = await Promise.all([getCourses(), getProducts(), getServices(), getArticles()]);
  const spaServices = services.filter((s) => s.type === "spa" || s.type === "peluqueria").slice(0, 3);
  return (
    <div>
      {/* HERO */}
      <section className="bg-brand-950 text-white overflow-hidden">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-10 lg:grid-cols-2 lg:pb-24 lg:pt-16">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-xs font-extrabold tracking-wide text-brand-100 ring-1 ring-white/20"><Sparkles className="h-4 w-4 text-accent-500" /> EDUCAN · ESCUELA DE ADIESTRAMIENTO PROFESIONAL</span>
            <h1 className="font-display mt-6 text-4xl font-semibold leading-[1.05] sm:text-5xl lg:text-[56px]">Un perro educado,<br />una familia <span className="text-accent-500">feliz.</span></h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-brand-100">Bienvenido a <b className="text-white">EducaInfo</b>, la app oficial de EDUCAN: cursos de adiestramiento paso a paso, asesoría de comportamiento, spa y peluquería profesional, accesorios y concentrado — todo para tu perro en un solo lugar.</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/registro" className="inline-flex items-center gap-2 rounded-full bg-accent-500 px-7 py-4 font-extrabold text-brand-950 shadow-lg hover:bg-accent-600">Empezar 7 días GRATIS <ArrowRight className="h-5 w-5" /></Link>
              <Link href="/entrenamiento" className="inline-flex items-center gap-2 rounded-full bg-white/10 px-7 py-4 font-extrabold text-white ring-1 ring-white/30 hover:bg-white/20"><GraduationCap className="h-5 w-5" /> Ver cursos</Link>
            </div>
            <p className="mt-3 text-sm font-bold text-brand-100">Sin tarjeta · Cancela cuando quieras · Luego desde $29.900/mes</p>
            <div className="mt-9 grid grid-cols-3 max-w-md divide-x divide-white/15 rounded-2xl bg-white/5 ring-1 ring-white/10">
              {[["+1.200", "perros educados"], ["15 años", "de experiencia"], ["4.9/5", "calificación"]].map(([n, l]) => (
                <div key={l} className="px-4 py-4 text-center"><p className="font-display text-2xl font-semibold text-accent-500">{n}</p><p className="text-[11px] font-bold uppercase tracking-wide text-brand-100">{l}</p></div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="overflow-hidden rounded-[2rem] ring-8 ring-white/10">
              <img src={IMG.hero} alt="Entrenamiento canino EDUCAN" className="h-[420px] w-full object-cover lg:h-[520px]" />
            </div>
            <div className="absolute -left-3 top-6 rounded-2xl bg-white p-4 shadow-2xl sm:-left-6">
              <p className="flex items-center gap-2 text-sm font-black text-brand-950"><Timer className="h-5 w-5 text-emerald-500" /> Prueba gratuita</p>
              <p className="font-display text-3xl font-semibold text-brand-900">7 días</p>
              <p className="text-xs font-bold text-slate-500">acceso total a cursos</p>
            </div>
            <div className="absolute -bottom-5 right-4 flex items-center gap-3 rounded-2xl bg-white p-4 shadow-2xl">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-emerald-100"><BadgeCheck className="h-6 w-6 text-emerald-600" /></span>
              <div><p className="text-sm font-black text-brand-950">Adiestradores EDUCAN</p><p className="text-xs font-bold text-slate-500">Método positivo, sin castigos</p></div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICIOS */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="text-center">
          <span className="rounded-full bg-brand-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-brand-700">TODO PARA TU PERRO</span>
          <h2 className="font-display mt-4 text-3xl font-semibold text-brand-950 sm:text-4xl">Cuatro servicios, una sola app</h2>
          <p className="mx-auto mt-3 max-w-2xl text-slate-600">EducaInfo reúne la experiencia de EDUCAN en tu bolsillo: aprende, resuelve, consiente y alimenta a tu mejor amigo.</p>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: GraduationCap, title: "Adiestramiento canino", desc: "Cursos en video y guías paso a paso: cachorros, obediencia, paseo sin tirones y nivel avanzado.", href: "/entrenamiento", cta: "Ver cursos", badge: "7 días gratis" },
            { icon: HeartHandshake, title: "Asesoría de comportamiento", desc: "Ansiedad, ladridos, miedos y reactividad. Guías prácticas y asesoría personalizada con expertos.", href: "/comportamiento", cta: "Resolver mi caso", badge: "Con especialistas" },
            { icon: Scissors, title: "Spa y peluquería", desc: "Baño spa, corte profesional y servicio a domicilio sin costo de transporte. Tu perro, hermoso y relajado.", href: "/spa", cta: "Reservar cita", badge: "A domicilio" },
            { icon: ShoppingBag, title: "Tienda y concentrado", desc: "Concentrado premium, premios de entrenamiento, arneses, correas y productos de cuidado recomendados.", href: "/tienda", cta: "Ir a la tienda", badge: "Envío a domicilio" },
          ].map((s) => (
            <Link key={s.title} href={s.href} className="group rounded-3xl border border-brand-100 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-900 text-white group-hover:bg-accent-500 group-hover:text-brand-950 transition"><s.icon className="h-7 w-7" /></span>
              <span className="mt-4 inline-block rounded-full bg-accent-100 px-2.5 py-1 text-[11px] font-extrabold text-accent-600">{s.badge}</span>
              <h3 className="font-display mt-2 text-xl font-semibold text-brand-950">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{s.desc}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-extrabold text-brand-700">{s.cta} <ChevronRight className="h-4 w-4 transition group-hover:translate-x-1" /></span>
            </Link>
          ))}
        </div>
      </section>

      {/* CÓMO FUNCIONA LA PRUEBA */}
      <section className="bg-brand-900 py-16 text-white">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid items-center gap-10 lg:grid-cols-[1fr_1.2fr]">
            <div>
              <span className="rounded-full bg-accent-500 px-4 py-1.5 text-xs font-extrabold tracking-widest text-brand-950">MODELO EDUCAR SIN RIESGO</span>
              <h2 className="font-display mt-4 text-3xl font-semibold sm:text-4xl">7 días gratis. Después, tú decides.</h2>
              <p className="mt-4 leading-relaxed text-brand-100">Sabemos que amas a tu mascota y que su cuidado es lo más importante. Por eso te dejamos probar TODO el adiestramiento de EducaInfo durante una semana, sin pedirte tarjeta. Si tu perro avanza (y va a avanzar), eliges el plan que quieras.</p>
              <Link href="/planes" className="mt-6 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 font-extrabold text-brand-900 hover:bg-brand-100"><Crown className="h-5 w-5 text-accent-600" /> Conocer los planes Premium</Link>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              {[
                { icon: ClipboardList, n: "Día 1", t: "Regístrate gratis", d: "Crea tu cuenta y el perfil de tu perro en 1 minuto. Sin tarjeta." },
                { icon: BookOpenCheck, n: "Días 1–7", t: "Entrena sin límites", d: "Acceso total a cursos, lecciones y guías de comportamiento." },
                { icon: Wallet, n: "Día 8", t: "Elige tu plan", d: "Desde $29.900/mes. Si no continúas, conservas las lecciones gratuitas." },
              ].map((s) => (
                <div key={s.n} className="rounded-3xl bg-white/10 p-6 ring-1 ring-white/15">
                  <s.icon className="h-8 w-8 text-accent-500" />
                  <p className="mt-4 text-xs font-extrabold tracking-widest text-accent-500">{s.n}</p>
                  <h3 className="font-display mt-1 text-lg font-semibold">{s.t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-brand-100">{s.d}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CURSOS DESTACADOS */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div><span className="rounded-full bg-brand-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-brand-700">ESCUELA ONLINE EDUCAN</span>
          <h2 className="font-display mt-3 text-3xl font-semibold text-brand-950">Cursos de adiestramiento</h2>
          <p className="mt-2 text-slate-600">Lecciones cortas de 10 minutos, tareas diarias y seguimiento de progreso. Primera lección de cada curso abierta para todos.</p></div>
          <Link href="/entrenamiento" className="inline-flex items-center gap-1 rounded-full bg-brand-900 px-5 py-3 text-sm font-extrabold text-white hover:bg-brand-700">Todos los cursos <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-3">{courses.slice(0, 3).map((c) => <CourseCard key={c.id} course={c} />)}</div>
      </section>

      {/* SPA */}
      <section className="bg-white py-16">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 lg:grid-cols-2">
          <div className="relative order-2 lg:order-1">
            <img src={IMG.spa1} alt="Spa canino EDUCAN" className="h-[440px] w-full rounded-[2rem] object-cover" />
            <div className="absolute bottom-5 left-5 flex items-center gap-3 rounded-2xl bg-brand-950/90 px-5 py-4 text-white backdrop-blur">
              <Truck className="h-8 w-8 text-accent-500" />
              <div><p className="font-display text-lg font-semibold leading-none">Servicio a domicilio</p><p className="text-xs font-bold text-brand-100">Sin costo de transporte en la zona</p></div>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <span className="rounded-full bg-accent-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-accent-600">EDUCAN PELUQUERÍA</span>
            <h2 className="font-display mt-4 text-3xl font-semibold text-brand-950 sm:text-4xl">Spa y peluquería canina profesional</h2>
            <p className="mt-4 leading-relaxed text-slate-600">Porque sabemos que amas a tu mascota, la consentimos con productos profesionales, sin jaulas y con reporte fotográfico. Reserva en la app y paga al recibir el servicio.</p>
            <div className="mt-6 space-y-3">
              {spaServices.map((s) => (
                <Link key={s.id} href="/spa" className="flex items-center justify-between gap-4 rounded-2xl border border-brand-100 bg-cream px-5 py-4 transition hover:border-accent-500">
                  <div><p className="font-extrabold text-brand-950">{s.name}</p><p className="text-sm text-slate-500 line-clamp-1">{s.description}</p></div>
                  <span className="shrink-0 font-display text-lg font-semibold text-brand-700">{fmtCOP_PLACEHOLDER(s.price)}</span>
                </Link>
              ))}
            </div>
            <Link href="/spa" className="mt-6 inline-flex items-center gap-2 rounded-full bg-brand-900 px-6 py-3.5 font-extrabold text-white hover:bg-brand-700"><CalendarCheck2 className="h-5 w-5" /> Reservar mi cita</Link>
          </div>
        </div>
      </section>

      {/* TIENDA */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div><span className="rounded-full bg-brand-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-brand-700">TIENDA EDUCAN</span>
          <h2 className="font-display mt-3 text-3xl font-semibold text-brand-950">Concentrado y accesorios</h2>
          <p className="mt-2 text-slate-600">Lo mismo que recomendamos en clase, directo a tu puerta.</p></div>
          <Link href="/tienda" className="inline-flex items-center gap-1 rounded-full bg-brand-900 px-5 py-3 text-sm font-extrabold text-white hover:bg-brand-700">Ver tienda <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">{products.slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>
      </section>

      {/* COMPORTAMIENTO */}
      <section className="bg-brand-50 py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="text-center">
            <span className="rounded-full bg-brand-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-brand-700">ASESORÍA DE COMPORTAMIENTO</span>
            <h2 className="font-display mt-4 text-3xl font-semibold text-brand-950">¿Algo te preocupa de tu perro?</h2>
            <p className="mx-auto mt-3 max-w-2xl text-slate-600">Guías escritas por nuestros adiestradores y la opción de una asesoría personalizada para tu caso.</p>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {articles.slice(0, 3).map((a) => (
              <Link key={a.id} href={`/comportamiento/${a.slug}`} className="group overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-brand-100 transition hover:shadow-xl">
                <img src={a.image} alt={a.title} className="h-44 w-full object-cover transition duration-500 group-hover:scale-105" />
                <div className="p-5">
                  <span className="rounded-full bg-accent-100 px-2.5 py-1 text-[11px] font-extrabold text-accent-600">{a.category}</span>
                  <h3 className="font-display mt-3 text-lg font-semibold leading-snug text-brand-950">{a.title}</h3>
                  <p className="mt-2 line-clamp-2 text-sm text-slate-600">{a.excerpt}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-extrabold text-brand-700">Leer guía · {a.readMin} min <ChevronRight className="h-4 w-4" /></span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* PRESENTACIÓN / QUIÉNES SOMOS */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="overflow-hidden rounded-[2rem] bg-brand-950 text-white">
          <div className="grid lg:grid-cols-2">
            <div className="p-8 sm:p-12">
              <span className="rounded-full bg-white/10 px-4 py-1.5 text-xs font-extrabold tracking-widest text-brand-100 ring-1 ring-white/20">PRESENTACIÓN OFICIAL</span>
              <h2 className="font-display mt-5 text-3xl font-semibold leading-tight">EDUCAN presenta <span className="text-accent-500">EducaInfo</span></h2>
              <p className="mt-4 leading-relaxed text-brand-100">EDUCAN es una escuela de adiestramiento profesional con sede en San Felipe. Creamos EducaInfo para que ninguna familia se quede sin ayuda: educación canina de calidad, asequible y acompañada por profesionales, desde el celular.</p>
              <ul className="mt-6 space-y-3">
                {["Método 100% positivo, sin castigos ni collares de ahogo", "Adiestradores profesionales con experiencia en todas las razas", "Spa y peluquería con protocolos de higiene certificados", "Servicio a domicilio para tu comodidad y la de tu perro"].map((t) => (
                  <li key={t} className="flex gap-2.5 font-semibold text-brand-50"><CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-400" />{t}</li>
                ))}
              </ul>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href={`https://wa.me/${WHATSAPP}`} target="_blank" className="inline-flex items-center gap-2 rounded-full bg-emerald-500 px-6 py-3.5 font-extrabold text-white hover:bg-emerald-600"><MessageCircle className="h-5 w-5" /> Hablar con EDUCAN</a>
                <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-5 py-3.5 text-sm font-bold ring-1 ring-white/20"><MapPin className="h-4 w-4 text-accent-500" />{ADDRESS}</span>
              </div>
            </div>
            <img src={IMG.advanced} alt="Adiestrador EDUCAN trabajando" className="h-72 w-full object-cover lg:h-full" />
          </div>
        </div>
      </section>

      {/* TESTIMONIOS */}
      <section className="mx-auto max-w-7xl px-4 pb-16">
        <div className="text-center">
          <span className="rounded-full bg-brand-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-brand-700">FAMILIAS EDUCAN</span>
          <h2 className="font-display mt-4 text-3xl font-semibold text-brand-950">Lo que dicen nuestros clientes</h2>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t) => (
            <article key={t.name} className="rounded-3xl border border-brand-100 bg-white p-6 shadow-sm">
              <div className="flex gap-0.5">{Array.from({ length: t.stars }).map((_, i) => <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />)}</div>
              <p className="mt-3 text-sm leading-relaxed text-slate-700">“{t.text}”</p>
              <p className="mt-4 font-display font-semibold text-brand-950">{t.name}</p>
              <p className="flex items-center gap-1 text-xs font-bold text-slate-500"><Dog className="h-3.5 w-3.5" />{t.dog}</p>
            </article>
          ))}
        </div>
      </section>

      {/* PLANES RESUMEN */}
      <section className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="text-center">
            <span className="rounded-full bg-accent-100 px-4 py-1.5 text-xs font-extrabold tracking-widest text-accent-600">DESPUÉS DE TU PRUEBA GRATIS</span>
            <h2 className="font-display mt-4 text-3xl font-semibold text-brand-950">Planes Premium EducaInfo</h2>
            <p className="mt-3 text-slate-600">Menos que un baño al mes, por un perro educado para toda la vida.</p>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {plans.map((p) => (
              <article key={p.id} className={`relative rounded-3xl border-2 p-7 ${p.badge ? "border-accent-500 bg-cream shadow-xl" : "border-brand-100 bg-white"}`}>
                {p.badge && <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-accent-500 px-4 py-1 text-xs font-black text-brand-950">{p.badge}</span>}
                <h3 className="font-display text-xl font-semibold text-brand-950">{p.name}</h3>
                <p className="mt-1 text-sm text-slate-500">{p.desc}</p>
                <p className="mt-4"><span className="font-display text-4xl font-semibold text-brand-900">{fmtCOP_PLACEHOLDER(p.price)}</span><span className="font-bold text-slate-500">{p.period}</span></p>
                <ul className="mt-5 space-y-2.5">{p.features.map((f) => <li key={f} className="flex gap-2 text-sm font-semibold text-slate-700"><CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" />{f}</li>)}</ul>
                <Link href="/planes" className={`mt-6 block rounded-full py-3.5 text-center font-extrabold ${p.badge ? "bg-accent-500 text-brand-950 hover:bg-accent-600" : "bg-brand-900 text-white hover:bg-brand-700"}`}>Empezar 7 días gratis</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ + CTA */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl font-semibold text-brand-950">Preguntas frecuentes</h2>
            <div className="mt-6 space-y-3">
              {[
                ["¿De verdad son 7 días gratis sin tarjeta?", "Sí. Solo necesitas tu correo. Al día 8 tú decides si continúas con un plan Premium; si no, tu cuenta queda con las lecciones gratuitas para siempre."],
                ["¿Los cursos sirven para cualquier raza y edad?", "Sí. Tenemos rutas para cachorros desde 2 meses, adultos y perros senior, de todas las razas y tamaños. El método es positivo y se adapta a cada perro."],
                ["¿El spa a domicilio tiene costo adicional?", "En nuestra zona de cobertura el transporte no tiene costo. Reservas en la app, vamos a tu casa con todos los productos y te enviamos fotos del proceso."],
                ["¿Cómo recibo el concentrado y los accesorios?", "Pides en la tienda de EducaInfo, confirmamos por WhatsApp y entregamos a domicilio o recoges en sede: Carrera 26 # 10-34, San Felipe."],
                ["¿Puedo hablar con un adiestrador real?", "Claro. Agenda una asesoría de comportamiento o una sesión presencial, o escríbenos al " + PHONES[0] + ". Somos personas reales de EDUCAN."],
              ].map(([q, a]) => (
                <details key={q} className="group rounded-2xl border border-brand-100 bg-white px-5 py-4">
                  <summary className="cursor-pointer list-none font-extrabold text-brand-950">{q}</summary>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{a}</p>
                </details>
              ))}
            </div>
          </div>
          <div className="flex flex-col justify-center rounded-[2rem] bg-accent-500 p-8 text-brand-950 sm:p-12">
            <ShieldCheck className="h-12 w-12" />
            <h2 className="font-display mt-4 text-3xl font-semibold leading-tight">Tu perro merece la mejor educación. Tu bolsillo, 7 días para comprobarlo.</h2>
            <p className="mt-3 font-semibold text-brand-900/80">Únete hoy a las familias EDUCAN. Instala EducaInfo en tu celular desde el navegador (Agregar a pantalla de inicio) y empieza ahora.</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/registro" className="rounded-full bg-brand-950 px-7 py-4 font-extrabold text-white hover:bg-brand-900">Crear mi cuenta gratis</Link>
              <a href="tel:+573162826043" className="inline-flex items-center gap-2 rounded-full bg-white/70 px-6 py-4 font-extrabold text-brand-950"><Phone className="h-5 w-5" />{PHONES[0]}</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

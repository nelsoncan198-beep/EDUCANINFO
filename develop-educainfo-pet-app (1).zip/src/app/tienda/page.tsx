import { ShoppingBag, Truck, ShieldCheck, MessageCircle } from "lucide-react";
import { getProducts } from "@/lib/catalog";
import { ShopExplorer } from "@/components/Explorers";

export const dynamic = "force-dynamic";

export default async function Page() {
  const products = await getProducts();
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="overflow-hidden rounded-[2rem] bg-brand-950 text-white">
        <div className="p-8 sm:p-12">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-extrabold tracking-widest ring-1 ring-white/20"><ShoppingBag className="h-4 w-4 text-accent-500" /> TIENDA EDUCAN</span>
          <h1 className="font-display mt-4 text-4xl font-semibold">Concentrado, accesorios y cuidado</h1>
          <p className="mt-3 max-w-2xl leading-relaxed text-brand-100">Los productos que recomendamos en clase y usamos en nuestro spa. Pide aquí, confirma por WhatsApp y recibe a domicilio o recoge en sede.</p>
          <div className="mt-6 flex flex-wrap gap-3 text-sm font-extrabold">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 ring-1 ring-white/20"><Truck className="h-4 w-4 text-accent-500" /> Entrega a domicilio</span>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 ring-1 ring-white/20"><ShieldCheck className="h-4 w-4 text-accent-500" /> Productos originales</span>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 ring-1 ring-white/20"><MessageCircle className="h-4 w-4 text-accent-500" /> Asesoría de nutrición gratis</span>
          </div>
        </div>
      </div>
      <div className="mt-10"><ShopExplorer products={products} /></div>
    </div>
  );
}

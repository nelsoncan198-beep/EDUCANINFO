import { BadgeCheck, CheckCircle2, Clock3, Home, MapPin, Scissors, Sparkles, Truck } from "lucide-react";
import { getServices } from "@/lib/catalog";
import { getCurrentUser } from "@/lib/auth";
import { fmtCOP } from "@/lib/format";
import { BookingForm } from "@/components/Forms";
import { IMG } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function Page() {
  const services = await getServices();
  const user = await getCurrentUser().catch(() => null);
  const spa = services.filter((s) => s.type === "spa" || s.type === "peluqueria" || s.type === "comportamiento" || s.type === "adiestramiento");
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="grid overflow-hidden rounded-[2rem] bg-brand-950 text-white lg:grid-cols-2">
        <div className="p-8 sm:p-12">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-extrabold tracking-widest ring-1 ring-white/20"><Scissors className="h-4 w-4 text-accent-500" /> EDUCAN PELUQUERÍA · SAN FELIPE</span>
          <h1 className="font-display mt-4 text-4xl font-semibold">Spa y peluquería canina profesional</h1>
          <p className="mt-3 leading-relaxed text-brand-100">Sabemos que amas a tu mascota y que su cuidado es lo más importante. Por eso nuestro spa trabaja sin jaulas, con productos profesionales y con reporte fotográfico de todo el proceso.</p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {[["Servicio a domicilio", "Sin costo de transporte en la zona", Truck], ["Sin jaulas ni esperas", "Atención uno a uno, sin estrés", BadgeCheck], ["Higiene certificada", "Protocolos de desinfección en cada servicio", Sparkles], ["En sede San Felipe", "Carrera 26 # 10-34", MapPin]].map(([t, d, Icon]) => {
              const I = Icon as typeof Truck;
              return (<div key={t as string} className="rounded-2xl bg-white/10 p-4 ring-1 ring-white/15"><I className="h-6 w-6 text-accent-500" /><p className="mt-2 font-extrabold">{t as string}</p><p className="text-xs font-semibold text-brand-100">{d as string}</p></div>);
            })}
          </div>
        </div>
        <img src={IMG.spa2} alt="Peluquería canina profesional" className="h-72 w-full object-cover lg:h-full" />
      </div>

      <div className="mt-12 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
        <div>
          <h2 className="font-display text-3xl font-semibold text-brand-950">Nuestros servicios</h2>
          <p className="mt-2 text-slate-600">Precios desde, según tamaño y estado del manto. Confirmamos el valor exacto por WhatsApp antes de tu cita.</p>
          <div className="mt-7 grid gap-6 sm:grid-cols-2">
            {spa.map((s) => (
              <article key={s.id} className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-brand-100">
                <div className="relative h-44"><img src={s.image} alt={s.name} className="h-full w-full object-cover" />
                  <span className="absolute left-3 top-3 rounded-full bg-brand-950/85 px-3 py-1 text-[11px] font-extrabold text-white">{s.type === "spa" ? "Spa" : s.type === "peluqueria" ? "Peluquería" : s.type === "comportamiento" ? "Comportamiento" : "Adiestramiento"}</span>
                  {s.homeService && <span className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-accent-500 px-2.5 py-1 text-[11px] font-extrabold text-brand-950"><Home className="h-3 w-3" /> A domicilio</span>}
                </div>
                <div className="p-5">
                  <div className="flex items-start justify-between gap-3"><h3 className="font-display text-lg font-semibold leading-snug text-brand-950">{s.name}</h3><span className="shrink-0 font-display text-lg font-semibold text-brand-700">{fmtCOP(s.price)}</span></div>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{s.description}</p>
                  <p className="mt-2 inline-flex items-center gap-1 text-xs font-extrabold text-slate-500"><Clock3 className="h-3.5 w-3.5" />{s.durationMin >= 480 ? "Día completo" : `${s.durationMin} min aprox.`}</p>
                  <ul className="mt-3 space-y-1.5">{(s.includes as string[]).map((i) => <li key={i} className="flex gap-2 text-[13px] font-semibold text-slate-600"><CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />{i}</li>)}</ul>
                </div>
              </article>
            ))}
          </div>
        </div>
        <div className="lg:sticky lg:top-32 self-start">
          <BookingForm services={spa.map((s) => ({ name: s.name, price: s.price }))} userName={user?.name || ""} userPhone={user?.phone || ""} />
          <div className="mt-5 rounded-3xl bg-accent-100 p-5 ring-1 ring-accent-500/40">
            <p className="font-display text-lg font-semibold text-brand-950">Clientes Premium ahorran más</p>
            <p className="mt-1 text-sm font-semibold text-brand-900/70">Con tu suscripción EducaInfo recibes 10–20% de descuento en spa y peluquería, para siempre.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

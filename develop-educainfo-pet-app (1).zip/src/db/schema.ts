import {
  pgTable, serial, text, integer, boolean, timestamp, jsonb, uniqueIndex,
} from "drizzle-orm/pg-core";

/* ---------- Usuarios y suscripción ---------- */
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull().default(""),
  passwordHash: text("password_hash").notNull(),
  plan: text("plan").notNull().default("trial"), // trial | premium | expired
  trialStart: timestamp("trial_start").notNull().defaultNow(),
  trialEnd: timestamp("trial_end").notNull(),
  subscriptionEnd: timestamp("subscription_end"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const dogs = pgTable("dogs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  breed: text("breed").notNull().default(""),
  ageLabel: text("age_label").notNull().default(""),
  size: text("size").notNull().default("Mediano"),
  behaviorNotes: text("behavior_notes").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ---------- Catálogo de adiestramiento ---------- */
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  level: text("level").notNull().default("Inicial"),
  category: text("category").notNull().default("Obediencia"),
  durationLabel: text("duration_label").notNull().default(""),
  image: text("image").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  steps: jsonb("steps").$type<string[]>().notNull().default([]),
  durationMin: integer("duration_min").notNull().default(10),
  isPreview: boolean("is_preview").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const progress = pgTable("progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  lessonId: integer("lesson_id").notNull().references(() => lessons.id, { onDelete: "cascade" }),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
}, (t) => [uniqueIndex("progress_user_lesson_idx").on(t.userId, t.lessonId)]);

/* ---------- Servicios (spa, peluquería, asesorías) ---------- */
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull(), // spa | peluqueria | comportamiento | adiestramiento
  description: text("description").notNull(),
  price: integer("price").notNull(),
  durationMin: integer("duration_min").notNull().default(60),
  image: text("image").notNull().default(""),
  includes: jsonb("includes").$type<string[]>().notNull().default([]),
  homeService: boolean("home_service").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  dogName: text("dog_name").notNull(),
  serviceName: text("service_name").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  mode: text("mode").notNull().default("sede"), // sede | domicilio
  status: text("status").notNull().default("Pendiente"),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ---------- Tienda ---------- */
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // Concentrado | Accesorios | Cuidado
  price: integer("price").notNull(),
  oldPrice: integer("old_price"),
  image: text("image").notNull().default(""),
  stock: integer("stock").notNull().default(20),
  badge: text("badge").notNull().default(""),
  rating: text("rating").notNull().default("4.8"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull().default(""),
  items: jsonb("items").$type<{ name: string; qty: number; price: number }[]>().notNull().default([]),
  total: integer("total").notNull(),
  status: text("status").notNull().default("Recibido"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/* ---------- Contenido de comportamiento ---------- */
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  excerpt: text("excerpt").notNull(),
  content: jsonb("content").$type<string[]>().notNull().default([]),
  readMin: integer("read_min").notNull().default(5),
  image: text("image").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const consultations = pgTable("consultations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  dogName: text("dog_name").notNull(),
  issue: text("issue").notNull(),
  status: text("status").notNull().default("Solicitada"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  plan: text("plan").notNull(),
  amount: integer("amount").notNull(),
  status: text("status").notNull().default("Activa"),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  endsAt: timestamp("ends_at").notNull(),
});
